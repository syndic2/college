package com.nix.mdpm1_6615;

import java.util.ArrayList;

class Player {
    private int score;
    private int matches;
    private boolean turn;
    private ArrayList<Card> opened;

    Player(boolean turn) {
        this.score= 0;
        this.matches= 0;
        this.turn= turn;
        this.opened= new ArrayList<>();
    }

    public int getScore() { return this.score; }
    public int getMatches() { return this.matches; }
    public boolean isTurn() { return this.turn; }

    public ArrayList<Card> getOpened() { return this.opened; }

    public boolean isCardMatch() {

        if (this.opened.get(0).getColor() == this.opened.get(1).getColor()) {
            this.matches+= 1;
            return true;
        }

        return false;
    }

    public void setScore(int score) { this.score += score; }
    public void setTurn(boolean turn) { this.turn = turn; }

    public void open(Card card) {

        if (this.opened.size() < 2) {
            card.setColor();

            this.opened.add(card);
        }
    }

    public void discard() {
        for (Card card : opened) {
            card.close();
        }

        opened.clear();
    }

    public void removeCard() {
        for (Card card : opened) {
            card.removeBody();
        }

        opened.clear();
    }
}
