package com.nix.mdpm1_6615;

import android.graphics.Color;
import android.view.View;
import android.widget.Button;

class Card {
    private Button body;
    private int currentColor;
    private int defaultColor;

    Card(Button body, int currentColor) {
        this.body= body;
        this.currentColor= currentColor;
        this.defaultColor= Color.WHITE;
        this.initialize();
    }

    public Button getBody() { return this.body; }
    public int getColor() { return this.currentColor; }

    public void initialize() {
        this.body.setText("?");
        this.body.setTextSize(24);
        this.body.setEnabled(true);
        this.body.setVisibility(View.VISIBLE);
        this.body.setBackgroundColor(this.defaultColor);
    }

    public void setColor() {
        this.body.setText("");
        this.body.setEnabled(false);
        this.body.setBackgroundColor(this.currentColor);
    }

    public void close() {
        this.body.setText("?");
        this.body.setEnabled(true);
        this.body.setBackgroundColor(defaultColor);
    }

    public void removeBody() {
        this.body.setEnabled(false);
        this.body.setVisibility(View.INVISIBLE);
    }
}
