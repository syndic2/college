package com.nix.mdpm1_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Random r;
    Handler handler;
    boolean singleplayer, multiplayer;
    ArrayList<Integer> colors;
    ArrayList<Card> cards;
    Player p1, p2;
    TextView p1Label, p2Label;
    TextView p1Score, p2Score;
    Button[] modes, bodies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        r= new Random();
        handler= new Handler();
        colors= new ArrayList<Integer>();
        cards= new ArrayList<Card>();
        singleplayer= false;
        multiplayer= false;
        p1Label= findViewById(R.id.tView_P1);
        p2Label= findViewById(R.id.tView_P2);
        p1Score= findViewById(R.id.tView_ScoreP1);
        p2Score= findViewById(R.id.tView_ScoreP2);
        modes= new Button[] {
                findViewById(R.id.btn_Singleplayer),
                findViewById(R.id.btn_Multiplayer)
        };
        bodies= new Button[] {
                findViewById(R.id.btn_1),
                findViewById(R.id.btn_2),
                findViewById(R.id.btn_3),
                findViewById(R.id.btn_4),
                findViewById(R.id.btn_5),
                findViewById(R.id.btn_6),
                findViewById(R.id.btn_7),
                findViewById(R.id.btn_8),
                findViewById(R.id.btn_9),
                findViewById(R.id.btn_10),
                findViewById(R.id.btn_11),
                findViewById(R.id.btn_12),
        };

        initialize();

        for (final Button mode : modes) {
            mode.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mode.getId() == R.id.btn_Singleplayer) {
                        singleplayer= true;
                        multiplayer= false;
                    } else if (mode.getId() == R.id.btn_Multiplayer) {
                        singleplayer= false;
                        multiplayer= true;
                    }

                    initialize();
                }
            });
        }

        for (final Card card: cards) {
            card.getBody().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (singleplayer) {
                        p1.open(card);

                        if (p1.getOpened().size() == 2) {
                            if (p1.isCardMatch()) {
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        p1.removeCard();
                                    }
                                }, 250);
                            } else {
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        p1.discard();
                                    }
                                }, 250);
                            }
                        }

                        if (p1.getMatches() == 6) {
                            singleplayer= false;
                            multiplayer= false;

                            initialize();

                            Toast.makeText(
                                    MainActivity.this,
                                    "You Win!",
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                    } else if (multiplayer) {
                        if (p1.isTurn()) {
                            p1.open(card);

                            if (p1.getOpened().size() == 2)  {
                                if (p1.isCardMatch()) {
                                    p1.setScore(1);
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            p1.removeCard();
                                        }
                                    }, 250);
                                } else {
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            p1.discard();
                                        }
                                    }, 250);
                                }

                                p1.setTurn(false);
                                p2.setTurn(true);
                            }
                        } else if (p2.isTurn()) {
                            p2.open(card);

                            if (p2.getOpened().size() == 2) {
                                if (p2.isCardMatch()) {
                                    p2.setScore(1);
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            p2.removeCard();
                                        }
                                    }, 250);
                                } else {
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            p2.discard();
                                        }
                                    }, 250);
                                }

                                p1.setTurn(true);
                                p2.setTurn(false);
                            }
                        }

                        if ((p1.getMatches() + p2.getMatches()) - 6 == 0) {
                            if (p1.getScore() > p2.getScore()) {
                                Toast.makeText(
                                        MainActivity.this,
                                        "Player 1 Win!",
                                        Toast.LENGTH_SHORT
                                ).show();
                            } else if (p1.getScore() < p2.getScore()) {
                                Toast.makeText(
                                        MainActivity.this,
                                        "Player 2 Win!",
                                        Toast.LENGTH_SHORT
                                ).show();
                            } else {
                                Toast.makeText(
                                        MainActivity.this,
                                        "Draw!",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }

                            singleplayer= false;
                            multiplayer= false;

                            initialize();
                        }

                        setTurnPlayer();
                        setScorePlayer();
                    }
                }
            });
        }
    }

    private void createColors() {
        colors.add(getResources().getColor(R.color.red));
        colors.add(getResources().getColor(R.color.red));
        colors.add(getResources().getColor(R.color.blue));
        colors.add(getResources().getColor(R.color.blue));
        colors.add(getResources().getColor(R.color.yellow));
        colors.add(getResources().getColor(R.color.yellow));
        colors.add(getResources().getColor(R.color.green));
        colors.add(getResources().getColor(R.color.green));
        colors.add(getResources().getColor(R.color.black));
        colors.add(getResources().getColor(R.color.black));
        colors.add(getResources().getColor(R.color.orange));
        colors.add(getResources().getColor(R.color.orange));
    }

    private void initialize() {
        p1= new Player(true);
        p2= new Player(false);

        colors.clear();
        cards.clear();
        createColors();

        for (Button body : bodies) {
            cards.add(new Card(body, getRandomColor()));
        }

        setTurnPlayer();
        setScorePlayer();
    }

    private int getRandomColor() {
        int color= 0;
        int index= r.nextInt(colors.size());
        color= colors.get(index);

        colors.remove(index);

        return color;
    }

    private void setTurnPlayer() {

        if (p1.isTurn()) {
            p1Label.setTextColor(getResources().getColor(R.color.red));
            p1Score.setTextColor(getResources().getColor(R.color.red));

            p2Label.setTextColor(getResources().getColor(R.color.black));
            p2Score.setTextColor(getResources().getColor(R.color.black));
        } else if (p2.isTurn()) {
            p1Label.setTextColor(getResources().getColor(R.color.black));
            p1Score.setTextColor(getResources().getColor(R.color.black));

            p2Label.setTextColor(getResources().getColor(R.color.blue));
            p2Score.setTextColor(getResources().getColor(R.color.blue));
        }
    }

    private void setScorePlayer() {
        String score1= p1.getScore() + "";
        String score2= p2.getScore() + "";

        p1Score.setText(score1);
        p2Score.setText(score2);
    }
}
