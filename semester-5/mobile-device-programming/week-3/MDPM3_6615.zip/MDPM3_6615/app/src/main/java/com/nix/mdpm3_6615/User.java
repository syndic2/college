package com.nix.mdpm3_6615;

import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable {
    private String username, password;
    private ArrayList<Integer> wishlist;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.wishlist= new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public ArrayList<Integer> getWishlist() { return this.wishlist; }
    public void setWishlist(int id_barang) { this.wishlist.add(id_barang); }
    public void unWishlist(int id_barang) { this.wishlist.remove(this.wishlist.indexOf(id_barang)); }
}
