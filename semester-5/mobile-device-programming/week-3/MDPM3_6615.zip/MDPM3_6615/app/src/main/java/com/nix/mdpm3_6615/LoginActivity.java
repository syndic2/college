package com.nix.mdpm3_6615;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    EditText edtUsername, edtPassword;
    Button btnLogin;
    Intent page;
    ArrayList<User> users;
    int logged;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        edtUsername = findViewById(R.id.edt_Username);
        edtPassword = findViewById(R.id.edt_Password);
        btnLogin= findViewById(R.id.btn_Login);
        logged= -1;

        getUsersData();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username= edtUsername.getText().toString();
                String password= edtPassword.getText().toString();

                if (!username.isEmpty() && !password.isEmpty()) {
                    for (int i= 0; i<users.size(); i++) {
                        User u= users.get(i);
                        if (username.equals(u.getUsername()) && password.equals(u.getPassword())) {
                            logged= i;
                            break;
                        }
                    }

                    if (logged >= 0) {
                        Toast.makeText(
                                LoginActivity.this,
                                "Login berhasil!",
                                Toast.LENGTH_SHORT
                        ).show();

                        page= new Intent(LoginActivity.this, CatalogActivity.class);
                        page.putExtra("users", users);
                        page.putExtra("logged", logged);
                        startActivity(page);
                    } else {
                        Toast.makeText(
                                LoginActivity.this,
                                "Username atau password salah!",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                }
            }
        });
    }

    private void getUsersData() {

        if (getIntent().getSerializableExtra("users") != null) {
            users= (ArrayList<User>) getIntent().getSerializableExtra("users");
        } else {
            users= new ArrayList<>();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.login_register_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.item_Login) {
            page= new Intent(this, LoginActivity.class);
            page.putExtra("users", users);
            startActivity(page);
        } else if (item.getItemId() == R.id.item_Register) {
            page= new Intent(this, RegisterActivity.class);
            page.putExtra("users", users);
            startActivity(page);
        }

        return super.onOptionsItemSelected(item);
    }
}
