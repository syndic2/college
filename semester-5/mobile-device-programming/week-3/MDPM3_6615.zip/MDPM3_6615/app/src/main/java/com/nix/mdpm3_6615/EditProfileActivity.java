package com.nix.mdpm3_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;

public class EditProfileActivity extends AppCompatActivity implements View.OnClickListener{
    EditText edtUsername, edtNewPassword, edtOldPassword;
    Button btnSave, btnCancel;
    Intent page;
    ArrayList<User> users;
    int logged;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        edtUsername= findViewById(R.id.edt_Username);
        edtNewPassword= findViewById(R.id.edt_NewPassword);
        edtOldPassword= findViewById(R.id.edt_OldPassword);
        btnSave= findViewById(R.id.btn_Save);
        btnCancel= findViewById(R.id.btn_Cancel);

        btnSave.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

        getUsersData();
    }

    private void getUsersData() {

        if (getIntent().getSerializableExtra("users") != null) {
            users= (ArrayList<User>) getIntent().getSerializableExtra("users");
            logged= getIntent().getIntExtra("logged", 0);

            edtUsername.setText(users.get(logged).getUsername());
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn_Save) {
            String newPassword= edtNewPassword.getText().toString();
            String oldPassword= edtOldPassword.getText().toString();

            if (!newPassword.isEmpty() && !oldPassword.isEmpty()) {
                if (oldPassword.equals(users.get(logged).getPassword())) {
                    users.get(logged).setPassword(newPassword);
                    page= new Intent(this, CatalogActivity.class);
                    page.putExtra("users", users);
                    page.putExtra("logged", logged);
                    startActivity(page);

                    Toast.makeText(
                            this,
                            "Ganti password berhasil!",
                            Toast.LENGTH_SHORT
                    ).show();
                } else {
                    Toast.makeText(
                            this,
                            "Password lama salah!",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            }

        } else if (view.getId() == R.id.btn_Cancel) {
            page= new Intent(this, CatalogActivity.class);
            page.putExtra("users", users);
            page.putExtra("logged", logged);
            startActivity(page);
        }
    }
}
