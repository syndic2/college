package com.nix.mdpm3_6615;

import android.graphics.drawable.Drawable;

public class Barang {
    private int id;
    private Drawable img;
    private String name, price, sellerName, sellerPhone;

    public Barang(int id, Drawable img, String name, String price, String sellerName, String sellerPhone) {
        this.id= id;
        this.img= img;
        this.name = name;
        this.price = price;
        this.sellerName = sellerName;
        this.sellerPhone = sellerPhone;
    }

    public int getId() { return this.id; }
    public Drawable getImg() { return img; }
    public String getName() {
        return name;
    }
    public String getPrice() {
        return price;
    }
    public String getSellerName() {
        return sellerName;
    }
    public String getSellerPhone() {
        return sellerPhone;
    }
}
