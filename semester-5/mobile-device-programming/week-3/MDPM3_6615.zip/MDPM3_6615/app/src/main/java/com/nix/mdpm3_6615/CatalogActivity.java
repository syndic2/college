package com.nix.mdpm3_6615;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TableRow;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CatalogActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    Button btnSortBy;
    ArrayList<TableRow> contentRows;
    View clicked;
    Intent page;
    ArrayList<User> users;
    ArrayList<Barang> barangs;
    int logged;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);

        btnSortBy= findViewById(R.id.btn_SortBy);
        contentRows= new ArrayList<>();
        barangs= new ArrayList<>();

        btnSortBy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onCreatePopUpMenu(view);
            }
        });

        for (int i= 1; i<=4; i++) {
            String id= "content_"+i;
            int resID= getResources().getIdentifier(id, "id", getPackageName());
            TableRow row= findViewById(resID);
            row.setBackground(drawBorder());
            registerForContextMenu(row);
            contentRows.add(row);
        }

        getUsersData();
        createBarang();
        setContent();
    }

    private GradientDrawable drawBorder() {
        GradientDrawable gd= new GradientDrawable();
        gd.setColor(Color.WHITE);
        gd.setCornerRadius(5);
        gd.setStroke(7, Color.GRAY);

        return gd;
    }

    private void getUsersData() {

        if (getIntent().getSerializableExtra("users") != null) {
            users= (ArrayList<User>) getIntent().getSerializableExtra("users");
            logged= getIntent().getIntExtra("logged", 0);
        }
    }

    private void createBarang() {
        barangs.add(new Barang(
                1,
                getResources().getDrawable(R.drawable.fan),
                "Kipas Anti Masuk Angin",
                "1.000.000",
                "Edwin",
                "08100200300"
        ));

        barangs.add(new Barang(
                2,
                getResources().getDrawable(R.drawable.microwave),
                "Microwave Super Dingin",
                "2.000.000",
                "Michael",
                "08400500600"
        ));

        barangs.add(new Barang(
                3,
                getResources().getDrawable(R.drawable.smartphone),
                "HP Anti Lemot - Lemot Club",
                "3.000.000",
                "Alicia",
                "08700800900"
        ));

        barangs.add(new Barang(
                4,
                getResources().getDrawable(R.drawable.refrigerator),
                "Kulkas Panas Dingin",
                "4.000.000",
                "Robert",
                "081000200030"
        ));
    }

    private Barang getBarang() {

        for (int i= 0; i<contentRows.size(); i++) {
            TableRow row= contentRows.get(i);

            if (row.getId() == clicked.getId()) {
                return barangs.get(i);
            }
        }

        return null;
    }

    private void sortBarang(String sort) {

        switch (sort) {
            case "nama_asc":
                Collections.sort(barangs, new Comparator<Barang>() {
                    @Override
                    public int compare(Barang o1, Barang o2) {
                        return o1.getName().compareTo(o2.getName());
                    }
                });
                break;
            case "nama_desc":
                Collections.sort(barangs, new Comparator<Barang>() {
                    @Override
                    public int compare(Barang o1, Barang o2) {
                        return o1.getName().compareTo(o2.getName());
                    }
                });
                Collections.reverse(barangs);
                break;
            case "harga_asc":
                Collections.sort(barangs, new Comparator<Barang>() {
                    @Override
                    public int compare(Barang o1, Barang o2) {
                        return o1.getPrice().compareTo(o2.getPrice());
                    }
                });
                break;
            case "harga_desc":
                Collections.sort(barangs, new Comparator<Barang>() {
                    @Override
                    public int compare(Barang o1, Barang o2) {
                        return o1.getPrice().compareTo(o2.getPrice());
                    }
                });
                Collections.reverse(barangs);
                break;
        }
    }

    private void setContent() {

        for (int i= 0; i<4; i++) {
            Barang barang= barangs.get(i);
            String imgID= "img_"+(i+1);
            String txtNamaID= "namaBarang_"+(i+1);
            String txtHargaID= "hargaBarang_"+(i+1);
            String sellerID= "seller_"+(i+1);
            String phoneID= "telp_"+(i+1);
            String favoriteID= "heart_"+(i+1);

            int resImgID= getResources().getIdentifier(imgID, "id", getPackageName());
            int resTxtNamaID= getResources().getIdentifier(txtNamaID, "id", getPackageName());
            int resTxtHargaID= getResources().getIdentifier(txtHargaID, "id", getPackageName());
            int resSellerID= getResources().getIdentifier(sellerID, "id", getPackageName());
            int resPhoneID= getResources().getIdentifier(phoneID, "id", getPackageName());
            int resFavoriteID= getResources().getIdentifier(favoriteID, "id", getPackageName());

            ((ImageView) findViewById(resImgID)).setImageDrawable(barang.getImg());
            ((TextView) findViewById(resTxtNamaID)).setText(barang.getName());
            ((TextView) findViewById(resTxtHargaID)).setText(barang.getPrice());
            ((TextView) findViewById(resSellerID)).setText("Penjual: "+barang.getSellerName());
            ((TextView) findViewById(resPhoneID)).setText(barang.getSellerPhone());

            if (users.get(logged).getWishlist().contains(barangs.get(i).getId())) {
                ((ImageView) findViewById(resFavoriteID)).setVisibility(View.VISIBLE);
            } else {
                ((ImageView) findViewById(resFavoriteID)).setVisibility(View.INVISIBLE);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.catalog_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.item_EditProfile) {
            page= new Intent(this, EditProfileActivity.class);
            page.putExtra("users", users);
            page.putExtra("logged", logged);
            startActivity(page);
        } else if (item.getItemId() == R.id.item_Logout) {
            page= new Intent(this, LoginActivity.class);
            page.putExtra("users", users);
            startActivity(page);
        }

        return super.onOptionsItemSelected(item);
    }

    public void onCreatePopUpMenu(View view) {
        PopupMenu popup= new PopupMenu(this, view);
        popup.getMenuInflater().inflate(R.menu.sort_popup_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(this);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.sort_NamaASC:
                sortBarang("nama_asc");
                break;
            case R.id.sort_NamaDESC:
                sortBarang("nama_desc");
                break;
            case R.id.sort_HargaASC:
                sortBarang("harga_asc");
                break;
            case R.id.sort_HargaDESC:
                sortBarang("harga_desc");
                break;
        }

        setContent();

        return false;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.content_context_menu, menu);
        clicked= v;

        for (int i= 0; i<contentRows.size(); i++) {
            if (contentRows.get(i).getId() == clicked.getId()) {
                if (users.get(logged).getWishlist().contains(barangs.get(i).getId())) {
                    menu.getItem(0).setTitle("Hapus Dari Wishlist");
                } else {
                    menu.getItem(0).setTitle("Tambahkan Ke Wishlist");
                }
            }
        }
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.item_Wishlist) {
            if (item.getTitle().equals("Tambahkan Ke Wishlist")) {
                users.get(logged).setWishlist(getBarang().getId());
            } else if (item.getTitle().equals("Hapus Dari Wishlist")) {
                users.get(logged).unWishlist(getBarang().getId());
            }

            setContent();
        } else if (item.getItemId() == R.id.item_CallSeller) {
            String phone= getBarang().getSellerPhone();
            page= new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+phone));
            startActivity(page);
        }

        return super.onContextItemSelected(item);
    }
}
