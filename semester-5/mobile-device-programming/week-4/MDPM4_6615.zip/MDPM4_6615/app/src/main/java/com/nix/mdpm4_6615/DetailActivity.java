package com.nix.mdpm4_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.NumberFormat;
import java.util.Locale;

public class DetailActivity extends AppCompatActivity {
    Order order;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getExtrasData();
        getAndSetViews();
    }

    private void getExtrasData() {
        if (getIntent().getSerializableExtra("order") != null) {
            order= ((Order)getIntent().getSerializableExtra("order"));
            Toast.makeText(this, order.toString(), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "tidak ada data", Toast.LENGTH_SHORT).show();
        }
    }

    private void getAndSetViews() {
        ((TextView) findViewById(R.id.tvID)).append(order.getId());

        if (order.getStatus().equals("Belum diproses")) {
            ((TextView) findViewById(R.id.tvStatus)).setTextColor(Color.RED);
        } else if (order.getStatus().equals("Selesai diproses")) {
            ((TextView) findViewById(R.id.tvStatus)).setTextColor(Color.GREEN);
        }

        ((TextView) findViewById(R.id.tvStatus)).setText(order.getStatus());

        ArrayAdapter<Catalog> adapter= new ArrayAdapter(
                this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                order.getCatalogs()
        );

        ((ListView) findViewById(R.id.lvDetail)).setAdapter(adapter);

        NumberFormat rp= NumberFormat.getCurrencyInstance(new Locale("in", "ID"));

        ((TextView) findViewById(R.id.tvTotalPrice)).append(rp.format(order.getTotalPrice()));
        ((Button) findViewById(R.id.btnBack)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
