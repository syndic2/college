package com.nix.mdpm4_6615;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class AdminActivity extends AppCompatActivity {
    TextView tvIncome;
    ListView lvUnProcessed, lvProcessed;
    Intent page;
    NumberFormat rp;
    ArrayAdapter<Order> adapterUnProcessed, adapterProcessed;
    ArrayList<Order> orders, unProcessed, processed;
    int income;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        rp= NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        orders= new ArrayList<>();
        tvIncome= findViewById(R.id.tvIncome);

        getExtrasData();
        setUnProcessedAndProcessedList();
        getAndSetListViewItem();
    }

    private void getExtrasData() {
        if (getIntent().getSerializableExtra("orders") != null) {
            orders.addAll((ArrayList<Order>)getIntent().getSerializableExtra("orders"));
            income= getIntent().getIntExtra("income", 0);
            tvIncome.append(rp.format(income));
            Toast.makeText(this, orders.toString(), Toast.LENGTH_SHORT).show();
            Toast.makeText(this, income+"", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "tidak ada data", Toast.LENGTH_SHORT).show();
        }
    }

    private void setUnProcessedAndProcessedList() {
        unProcessed= new ArrayList<>();
        processed= new ArrayList<>();

        for (Order order : orders) {
            if (order.getStatus().equals("Belum diproses")) {
                unProcessed.add(order);
            } else if (order.getStatus().equals("Selesai diproses")) {
                processed.add(order);
            }
        }
    }

    private void getAndSetListViewItem() {
        adapterUnProcessed= new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                unProcessed
        );
        adapterProcessed= new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                processed
        );

        lvUnProcessed= findViewById(R.id.lvUnprocessed);
        lvProcessed= findViewById(R.id.lvProcessed);

        lvUnProcessed.setAdapter(adapterUnProcessed);
        lvProcessed.setAdapter(adapterProcessed);

        lvUnProcessed.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                onCreatePopUpMenu(adapterView, view, i);

                return false;
            }
        });

        lvProcessed.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                onCreatePopUpMenu(adapterView, view, i);

                return false;
            }
        });
    }

    private void seeDetailOrder(AdapterView<?> adapterView, int i) {
        Order order= null;

        if (adapterView.getId() == R.id.lvUnprocessed) order= unProcessed.get(i);
        else if (adapterView.getId() == R.id.lvProcessed) order= processed.get(i);

        page= new Intent(this, DetailActivity.class);
        page.putExtra("order", order);
        startActivity(page);
    }

    private void finishOrder(int i) {
        income+= unProcessed.get(i).getTotalPrice();
        unProcessed.get(i).setStatus("Selesai diproses");
        processed.add(unProcessed.get(i));
        unProcessed.remove(i);
        adapterUnProcessed.notifyDataSetChanged();
        adapterProcessed.notifyDataSetChanged();
        tvIncome.setText("Hasil Penjualan Hari Ini, "+rp.format(income));
    }

    private void rejectOrder(int i) {
        income-= 10000;
        unProcessed.remove(i);
        adapterUnProcessed.notifyDataSetChanged();
        tvIncome.setText("Hasil Penjualan Hari Ini, "+rp.format(income));
    }

    private void refreshOrders() {
        orders.clear();
        orders.addAll(unProcessed);
        orders.addAll(processed);
    }

    public void onCreatePopUpMenu(final AdapterView<?> adapterView, View view, final int i) {
        PopupMenu menu= new PopupMenu(this, view);
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menuDetailOrder:
                        seeDetailOrder(adapterView, i);
                        return true;
                    case R.id.menuFinishOrder:
                        finishOrder(i);
                        refreshOrders();
                        return true;
                    case R.id.menuRejectOrder:
                        rejectOrder(i);
                        refreshOrders();
                        return true;
                }

                return false;
            }
        });
        menu.getMenuInflater().inflate(R.menu.context_menu, menu.getMenu());

        if (adapterView.getId() == R.id.lvProcessed) {
            menu.getMenu().getItem(1).setVisible(false);
            menu.getMenu().getItem(2).setVisible(false);
        }

        menu.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menuLogout) {
            page= new Intent(this, LoginActivity.class);
            page.putExtra("orders", orders);
            page.putExtra("income", income);
            startActivity(page);
        }

        return super.onOptionsItemSelected(item);
    }
}
