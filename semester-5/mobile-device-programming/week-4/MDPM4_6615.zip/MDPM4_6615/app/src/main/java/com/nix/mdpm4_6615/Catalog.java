package com.nix.mdpm4_6615;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Locale;

public class Catalog implements Serializable {
    private String name;
    private int price, subTotal, qty;

    public Catalog(String name, int price) {
        this.name = name;
        this.price = price;
        this.subTotal= 0;
        this.qty= 0;
    }

    public int getSubTotal() { return subTotal; }
    public void setSubTotal() { this.subTotal = this.price*this.qty; }
    public int getQty() { return qty; }
    public void setQty(int qty) {
        this.qty += qty;
        if (this.qty <= 0 ) this.qty= 0;
    }

    @Override
    public String toString() {
        NumberFormat rp= NumberFormat.getCurrencyInstance(new Locale("in", "ID"));

        return this.name+" - "+this.qty+"pcs"+" - "+rp.format(this.subTotal);
    }
}
