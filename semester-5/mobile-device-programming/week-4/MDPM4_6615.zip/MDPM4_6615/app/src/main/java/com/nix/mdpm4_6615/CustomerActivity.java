package com.nix.mdpm4_6615;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class CustomerActivity extends AppCompatActivity {
    Intent page;
    String user;
    ArrayList<Order> orders;
    ArrayList<Catalog> catalogs;
    int income;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);
        orders= new ArrayList<>();

        getExtrasData();
        createCatalogs();
        getAndSetViews();
    }

    private void getExtrasData() {
        user= getIntent().getStringExtra("user");

        if (getIntent().getSerializableExtra("orders") != null) {
            orders.addAll((ArrayList<Order>)getIntent().getSerializableExtra("orders"));
            income= getIntent().getIntExtra("income", 0);
            Toast.makeText(this, orders.toString(), Toast.LENGTH_SHORT).show();
            Toast.makeText(this, income+"", Toast.LENGTH_SHORT).show();
        } else {
            orders= new ArrayList<>();
            Toast.makeText(this, "tidak ada data", Toast.LENGTH_SHORT).show();
        }
    }

    private void createCatalogs() {
        catalogs= new ArrayList<>();

        catalogs.add(new Catalog("Cheese Burger", 22000));
        catalogs.add(new Catalog("Milkshake", 12000));
        catalogs.add(new Catalog("French Fries", 16000));
        catalogs.add(new Catalog("Ice Cream", 10000));
    }

    private void getAndSetViews() {
        ((TextView) findViewById(R.id.tvUser)).setText("Welcome, "+user+"!");

        for (int i= 0; i<4; i++) {
            final int idx= i;
            String tvQty= "tvQty"+(i+1);
            String btnMinus= "btnMinus"+(i+1);
            String btnPlus= "btnPlus"+(i+1);

            int restQty= getResources().getIdentifier(tvQty, "id", getPackageName());
            int resMinus= getResources().getIdentifier(btnMinus, "id", getPackageName());
            int resPlus= getResources().getIdentifier(btnPlus, "id", getPackageName());

            final TextView qty= findViewById(restQty);
            ((Button) findViewById(resMinus)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    catalogs.get(idx).setQty(-1);
                    qty.setText(catalogs.get(idx).getQty()+"");
                }
            });
            ((Button) findViewById(resPlus)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    catalogs.get(idx).setQty(1);
                    qty.setText(catalogs.get(idx).getQty()+"");
                }
            });
        }

        ((Button) findViewById(R.id.btnCheckout)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Order order= new Order(autoGenID(user));

                for (Catalog catalog : catalogs) {
                    if (catalog.getQty() > 0) {
                        order.setCatalogs(catalog);
                    }
                }

                order.setTotalPrice();
                orders.add(order);
                Toast.makeText(getApplicationContext(), orders.get(orders.size()-1).toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String autoGenID(String user) {
        int kode= 1, max= 0;
        user= user.substring(0, 3).toUpperCase();

        for (Order order : orders) {
            if (order.getId().substring(0, 3).equals(user)) {
                max= Integer.parseInt(order.getId().substring(3, 6))+1;
                kode= max;
            }
        }

        if (kode > 0 && kode < 10) return user+"00"+kode;
        else if (kode >= 10 && kode < 100) return user+"0"+kode;
        else if (kode >= 100 && kode < 1000) return user+kode;
        else return user;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menuLogout) {
            page= new Intent(this, LoginActivity.class);
            page.putExtra("orders", orders);
            page.putExtra("income", income);
            startActivity(page);
        }

        return super.onOptionsItemSelected(item);
    }
}
