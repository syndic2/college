package com.nix.mdpm4_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    EditText edtUsername, edtPassword;
    Button btnLogin;
    Intent page;
    ArrayList<Order> orders;
    int income;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        orders= new ArrayList<>();

        getExtrasData();

        edtUsername= findViewById(R.id.edtUsername);
        edtPassword= findViewById(R.id.edtPassword);
        btnLogin= findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder username= new StringBuilder(edtUsername.getText().toString());
                String password= edtPassword.getText().toString();

                if (username.toString().equals("admin") && password.equals("admin")) {
                    page= new Intent(getApplicationContext(), AdminActivity.class);
                    page.putExtra("orders", orders);
                    page.putExtra("income", income);
                    startActivity(page);
                } else {
                    if (username.reverse().toString().equals(password)) {
                        Toast.makeText(
                                LoginActivity.this,
                                "Login berhasil!",
                                Toast.LENGTH_SHORT
                        ).show();

                        page= new Intent(getApplicationContext(), CustomerActivity.class);
                        page.putExtra("user", username.reverse().toString());
                        page.putExtra("orders", orders);
                        page.putExtra("income", income);
                        startActivity(page);
                    } else {
                        Toast.makeText(LoginActivity.this, "Password salah!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void getExtrasData() {
        if (getIntent().getSerializableExtra("orders") != null) {
            orders.addAll((ArrayList<Order>)getIntent().getSerializableExtra("orders"));
            income= getIntent().getIntExtra("income", 0);
            Toast.makeText(this, orders.toString(), Toast.LENGTH_SHORT).show();
            Toast.makeText(this, income+"", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "tidak ada data", Toast.LENGTH_SHORT).show();
        }
    }
}
