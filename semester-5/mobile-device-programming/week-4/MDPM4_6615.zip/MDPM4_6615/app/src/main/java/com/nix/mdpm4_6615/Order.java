package com.nix.mdpm4_6615;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class Order implements Serializable {
    private String id, status;
    private ArrayList<Catalog> catalogs;
    private int totalPrice;

    public Order(String id) {
        this.id = id;
        this.status = "Belum diproses";
        this.catalogs= new ArrayList<>();
        this.totalPrice= 0;
    }

    public String getId() { return this.id; }
    public String getStatus() { return this.status; }
    public void setStatus(String status) { this.status = status; }
    public ArrayList<Catalog> getCatalogs() { return this.catalogs; }
    public void setCatalogs(Catalog catalog) { this.catalogs.add(catalog); }
    public int getTotalPrice() { return totalPrice; }
    public void setTotalPrice() {
        for (Catalog catalog : this.catalogs) {
            catalog.setSubTotal();
            this.totalPrice+= catalog.getSubTotal();
        }
    }

    @Override
    public String toString() {
        NumberFormat rp= NumberFormat.getCurrencyInstance(new Locale("in", "ID"));

        return this.id+" - "+rp.format(this.totalPrice);
    }
}
