package com.example.mdpm5_6615;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class InboxAdapter extends RecyclerView.Adapter<InboxAdapter.InboxViewHolder> {
    private ArrayList<Email> inbox;
    private OnItemClickCallback onItemClickCallback;
    private OnItemLongClickCallback onItemLongClickCallback;
    private OnImageViewClickCallback onImageViewClickCallback;

    public InboxAdapter(ArrayList<Email> inbox) {
        this.inbox = inbox;
    }

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public void setOnItemLongClickCallback(OnItemLongClickCallback onItemLongClickCallback) {
        this.onItemLongClickCallback = onItemLongClickCallback;
    }

    public void setOnImageViewClickCallback(OnImageViewClickCallback onImageViewClickCallback) {
        this.onImageViewClickCallback = onImageViewClickCallback;
    }

    @NonNull
    @Override
    public InboxViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.inbox_view, parent, false);

         return new InboxViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final InboxViewHolder holder, int position) {
        final Email mail= this.inbox.get(position);

        holder.tvIcon.setText(mail.getSender().getEmail().toUpperCase().charAt(0)+"");
        holder.tvSender.setText(mail.getSender().getEmail());
        holder.tvSubject.setText(mail.getSubject());
        holder.tvMessage.setHint(mail.getMessage());
        holder.tvDateTime.setText(mail.getDate());

        if (mail.isStarred()) holder.ivStar.setImageResource(R.drawable.starred);
        else holder.ivStar.setImageResource(R.drawable.unstarred);

        holder.ivStar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onImageViewClickCallback != null) {
                    onImageViewClickCallback.onStarClicked(holder.getAdapterPosition());
                }
            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (onItemLongClickCallback != null) {
                    onItemLongClickCallback.onItemLongClicked(view, holder.getAdapterPosition());
                }

                return false;
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onItemClickCallback != null) {
                    onItemClickCallback.onItemClicked(holder.getAdapterPosition());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.inbox.size();
    }

    public class InboxViewHolder extends RecyclerView.ViewHolder {
        TextView tvIcon, tvSender, tvSubject, tvMessage, tvDateTime;
        ImageView ivStar;

        public InboxViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvIcon= itemView.findViewById(R.id.tvIcon);
            this.tvSender= itemView.findViewById(R.id.tvSender);
            this.tvSubject= itemView.findViewById(R.id.tvSubject);
            this.tvMessage= itemView.findViewById(R.id.tvMessage);
            this.tvDateTime= itemView.findViewById(R.id.tvDateTime);
            this.ivStar= itemView.findViewById(R.id.ivStar);

            tvIcon.setBackground(this.drawBorder());
        }

        private GradientDrawable drawBorder() {
            GradientDrawable gd= new GradientDrawable();
            gd.setColor(Color.GREEN);
            gd.setCornerRadius(7);
            gd.setStroke(5, Color.BLACK);

            return gd;
        }
    }

    public interface OnItemClickCallback { void onItemClicked(int position); }
    public interface OnItemLongClickCallback { void onItemLongClicked(View view, int position); }
    public interface OnImageViewClickCallback { void onStarClicked(int position); }
}
