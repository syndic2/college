package com.example.mdpm5_6615;

import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable {
    private String email;
    private ArrayList<Email> allInbox;
    private ArrayList<Email> starredInbox;
    private ArrayList<Email> trash;

    public User(String email) {
        this.email= email;
        this.allInbox= new ArrayList<>();
        this.starredInbox= new ArrayList<>();
        this.trash= new ArrayList<>();
    }

    @Override
    public String toString() {
        return this.email;
    }

    public String getEmail() { return this.email; }
    public ArrayList<Email> getAllInbox() { return this.allInbox; }
    public void setAllInbox(Email newEmail) { this.allInbox.add(newEmail); }
    public ArrayList<Email> getStarredInbox() { return starredInbox; }
    public void setStarredInbox(Email newStarred) { this.starredInbox.add(newStarred); }
    public ArrayList<Email> getTrash() { return this.trash; }
    public void setTrash(Email newTrash) { this.trash.add(newTrash); }
}
