package com.example.mdpm5_6615;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {
    TextView tvLogged;
    RecyclerView rvInbox;
    Button btnCompose;
    InboxAdapter adapter;
    Intent page;
    ArrayList<User> users;
    ArrayList<Email> displayInbox;
    int idxUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tvLogged= findViewById(R.id.tvLogged);
        rvInbox= findViewById(R.id.rvInbox);
        btnCompose= findViewById(R.id.btnCompose);
        users= new ArrayList<>();
        displayInbox= new ArrayList<>();

        getExtrasData();

        displayInbox.addAll(users.get(idxUser).getAllInbox());

        rvInbox.setHasFixedSize(true);
        rvInbox.setLayoutManager(new LinearLayoutManager(this));
        adapter= new InboxAdapter(displayInbox);
        rvInbox.setAdapter(adapter);

        adapter.setOnItemClickCallback(new InboxAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(int position) {
                if (!users.get(idxUser).getAllInbox().isEmpty() && !displayInbox.get(position).isDeleted()) {
                    page= new Intent(HomeActivity.this, DetailActivity.class);
                    page.putExtra("users", users);
                    page.putExtra("idxUser", idxUser);
                    page.putExtra("idxMail", position);
                    startActivity(page);
                }
            }
        });

        adapter.setOnItemLongClickCallback(new InboxAdapter.OnItemLongClickCallback() {
            @Override
            public void onItemLongClicked(View view, int position) {
                if (!users.get(idxUser).getAllInbox().isEmpty() && !displayInbox.get(position).isDeleted()) {
                    onCreatePopUpMenu(view, position);
                }
            }
        });

        adapter.setOnImageViewClickCallback(new InboxAdapter.OnImageViewClickCallback() {
            @Override
            public void onStarClicked(int position) {
                if (!users.get(idxUser).getAllInbox().isEmpty() && !displayInbox.get(position).isDeleted()) {
                    if (users.get(idxUser).getAllInbox().get(position).isStarred()) {
                        users.get(idxUser).getAllInbox().get(position).setStarred(false);
                    } else {
                        users.get(idxUser).getAllInbox().get(position).setStarred(true);
                    }

                    adapter.notifyDataSetChanged();
                }
            }
        });

        btnCompose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                page= new Intent(HomeActivity.this, ComposeActivity.class);
                page.putExtra("users", users);
                page.putExtra("idxUser", idxUser);
                startActivity(page);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuLogout:
                page= new Intent(this, LoginActivity.class);
                page.putExtra("users", users);
                startActivity(page);
                break;
            case R.id.menuStarred:
                users.get(idxUser).getStarredInbox().clear();

                for (Email mail : users.get(idxUser).getAllInbox()) {
                    if (mail.isStarred()) {
                        users.get(idxUser).setStarredInbox(mail);
                    }
                }

                displayInbox.clear();
                displayInbox.addAll(users.get(idxUser).getStarredInbox());
                adapter.notifyDataSetChanged();
                break;
            case R.id.menuAll:
                displayInbox.clear();
                displayInbox.addAll(users.get(idxUser).getAllInbox());
                adapter.notifyDataSetChanged();
                break;
            case R.id.menuTrash:
                displayInbox.clear();
                displayInbox.addAll(users.get(idxUser).getTrash());
                adapter.notifyDataSetChanged();
                break;
            case R.id.menuDeleteAll:
                if (!users.get(idxUser).getAllInbox().isEmpty()) {
                    for (Email mail : users.get(idxUser).getAllInbox()) {
                        mail.setDeleted(true);
                        users.get(idxUser).setTrash(mail);
                    }

                    users.get(idxUser).getAllInbox().clear();
                    displayInbox.clear();
                    displayInbox.addAll(users.get(idxUser).getAllInbox());
                    adapter.notifyDataSetChanged();
                }
                break;
        };

        return super.onOptionsItemSelected(item);
    }

    private void onCreatePopUpMenu(View view, final int position) {
        PopupMenu menu= new PopupMenu(this, view);
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.menuDelete) {
                    users.get(idxUser).getAllInbox().get(position).setDeleted(true);
                    users.get(idxUser).setTrash(users.get(idxUser).getAllInbox().get(position));
                    users.get(idxUser).getAllInbox().remove(position);
                    displayInbox.clear();
                    displayInbox.addAll(users.get(idxUser).getAllInbox());
                    adapter.notifyDataSetChanged();
                }

                return false;
            }
        });

        menu.getMenuInflater().inflate(R.menu.context_menu, menu.getMenu());
        menu.show();
    }

    private void getExtrasData() {
        page= getIntent();

        if (page.hasExtra("users") || page.hasExtra("idxUser")) {
            if (page.getSerializableExtra("users") != null) {
                users.addAll((ArrayList<User>) page.getSerializableExtra("users"));
            }

            if (page.getIntExtra("idxUser", 0) >= 0) {
                idxUser= page.getIntExtra("idxUser", 0);
                tvLogged.setText(tvLogged.getText()+users.get(idxUser).getEmail()+"!");
            }
        } else {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }
    }
}
