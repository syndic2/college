package com.example.mdpm5_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {
    TextView tvSubject, tvSender, tvDateTime, tvMessage;
    Button btnReply, btnBack;
    Intent page;
    ArrayList<User> users;
    int idxUser, idxMail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvSubject= findViewById(R.id.tvSubject);
        tvSender= findViewById(R.id.tvSender);
        tvDateTime= findViewById(R.id.tvDateTime);
        tvMessage= findViewById(R.id.tvMessage);
        btnReply= findViewById(R.id.btnReply);
        btnBack= findViewById(R.id.btnBack);
        users= new ArrayList<>();

        getExtrasData();

        btnReply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                page= new Intent(DetailActivity.this, ComposeActivity.class);
                page.putExtra("users", users);
                page.putExtra("idxUser", idxUser);
                page.putExtra("idxMail", idxMail);
                page.putExtra("reply", true);
                startActivity(page);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void getExtrasData() {
        page= getIntent();

        if (page.hasExtra("users") || page.hasExtra("idxUser") || page.hasExtra("idxMail")) {
            if (page.getSerializableExtra("users") != null) {
                users.addAll((ArrayList<User>) page.getSerializableExtra("users"));
            }

            if (page.getIntExtra("idxUser", 0) >= 0) {
                idxUser= page.getIntExtra("idxUser", 0);
            }

            if (page.getIntExtra("idxMail", 0) >= 0) {
                idxMail= page.getIntExtra("idxMail",0);

                if (!users.get(idxUser).getAllInbox().isEmpty()) {
                    tvSubject.setText(users.get(idxUser).getAllInbox().get(idxMail).getSubject());
                    tvSender.setText(tvSender.getText()+users.get(idxUser).getAllInbox().get(idxMail).getSender().getEmail());
                    tvMessage.setText(users.get(idxUser).getAllInbox().get(idxMail).getMessage());
                    tvDateTime.setText(users.get(idxUser).getAllInbox().get(idxMail).getDateTime());
                }
            }
        } else {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }
    }
}
