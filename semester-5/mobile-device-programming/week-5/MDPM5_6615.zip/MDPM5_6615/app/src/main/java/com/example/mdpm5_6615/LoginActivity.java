package com.example.mdpm5_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    EditText edtEmail, edtPassword;
    Button btnLogin;
    Intent page;
    ArrayList<User> users;
    int idxUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtEmail= findViewById(R.id.edtEmail);
        edtPassword= findViewById(R.id.edtPassword);
        btnLogin= findViewById(R.id.btnLogin);
        users= new ArrayList<>();

        getExtrasData();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email= edtEmail.getText().toString();
                String password= edtPassword.getText().toString();

                if (!email.isEmpty() && !password.isEmpty()) {
                    if (isEmail(email) && isPassword(email, password)) {
                        if (!users.isEmpty()) {
                            boolean same= false;

                            for (int i= 0; i<users.size(); i++) {
                                if (users.get(i).getEmail().equals(email)) {
                                    same= true;
                                    idxUser= i;
                                    break;
                                }
                            }

                            if (!same) {
                                users.add(new User(email));
                                idxUser= users.size()-1;
                            }
                        } else {
                            users.add(new User(email));
                            idxUser= users.size()-1;
                        }

                        page= new Intent(LoginActivity.this, HomeActivity.class);
                        page.putExtra("users", users);
                        page.putExtra("idxUser", idxUser);
                        startActivity(page);
                    } else {
                        Toast.makeText(LoginActivity.this, "Wrong e-mail or password!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Field must not empty!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isEmail(String email) {
        String depanAt= "", belakangAt= "", belakangDot= "";

        if (email.contains("@")) {
            depanAt= email.substring(0, email.indexOf("@"));
            belakangAt= email.substring(email.indexOf("@")+1);

            if (!depanAt.isEmpty() && !belakangAt.isEmpty()) {
                if (belakangAt.contains(".")) {
                    belakangDot= belakangAt.substring(belakangAt.indexOf(".")+1);
                }

                if (!belakangDot.isEmpty()) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean isPassword(String email, String password) {
        String check= email.substring(0, 3)+email.length();

        if (check.equals(password)) return true;

        return false;
    }

    private void getExtrasData() {
        page= getIntent();

        if (page.hasExtra("users")) {
            if (page.getSerializableExtra("users") != null) {
                ArrayList<User> extra= (ArrayList<User>) page.getSerializableExtra("users");
                users.addAll(extra);
            }
        } else {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }
    }
}
