package com.example.mdpm5_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class ComposeActivity extends AppCompatActivity {
    TextView tvSender;
    EditText edtRecipient, edtSubject, edtMessage;
    Button btnSend, btnCancel;
    Intent page;
    ArrayList<User> users;
    int idxUser, idxMail;
    boolean reply;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compose);

        tvSender= findViewById(R.id.tvSender);
        edtRecipient= findViewById(R.id.edtRecipient);
        edtSubject= findViewById(R.id.edtSubject);
        edtMessage= findViewById(R.id.edtMessage);
        btnSend= findViewById(R.id.btnSend);
        btnCancel= findViewById(R.id.btnCancel);
        users= new ArrayList<>();

        getExtrasData();

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String recipient= edtRecipient.getText().toString();
                String subject= edtSubject.getText().toString();
                String message= edtMessage.getText().toString();

                if (!recipient.isEmpty() && !subject.isEmpty() && !message.isEmpty()) {
                    if (recipient.contains("-")) {
                        String[] splits= recipient.split("-");

                        for (String split : splits) {
                            sendEmail(split, subject, message);
                        }
                    } else {
                        sendEmail(recipient, subject, message);
                    }

                    page= new Intent(ComposeActivity.this, HomeActivity.class);
                    page.putExtra("users", users);
                    page.putExtra("idxUser", idxUser);
                    startActivity(page);
                } else {
                    Toast.makeText(ComposeActivity.this, "Field must not empty!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void getExtrasData() {
        page= getIntent();

        if (page.hasExtra("users") || page.hasExtra("idxUser") || page.hasExtra("idxMail") || page.hasExtra("reply")) {
            if (page.getSerializableExtra("users") != null) {
                users.addAll((ArrayList<User>) page.getSerializableExtra("users"));
            }

            if (page.getIntExtra("idxUser", 0) >= 0) {
                idxUser= page.getIntExtra("idxUser", 0);
                tvSender.setText(tvSender.getText()+users.get(idxUser).getEmail());
            }

            if (page.getIntExtra("idxMail", 0) >= 0) {
                idxMail= page.getIntExtra("idxMail",0);
            }

            if (page.getBooleanExtra("reply", false)) {
                reply= page.getBooleanExtra("reply", false);

                if (reply) {
                    edtRecipient.setText(users.get(idxUser).getAllInbox().get(idxMail).getSender().getEmail());
                    edtSubject.setText("RE: "+users.get(idxUser).getAllInbox().get(idxMail).getSubject());
                }
            }
        } else {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendEmail(String recipient, String subject, String message) {
        int idx= -1;

        for (int i= 0; i<users.size(); i++) {
            if (users.get(i).getEmail().equals(recipient)) {
                idx= i;
                break;
            }
        }

        if (idx >= 0) {
            users.get(idx).setAllInbox(new Email(users.get(idxUser), subject, message));
        } else {
            User newUser= new User(recipient);
            newUser.setAllInbox(new Email(users.get(idxUser), subject, message));
            users.add(newUser);
        }
    }
}
