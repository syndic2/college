package com.example.mdpm5_6615;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Email implements Serializable {
    private User sender;
    private String subject, message, date, time;
    private boolean starred, deleted;

    public Email(User sender, String subject, String message) {
        this.sender= sender;
        this.subject= subject;
        this.message= message;
        this.date= getDateFormat();
        this.time= getTimeFormat();
        this.starred= false;
        this.deleted= false;
    }

    @Override
    public String toString() {
        return this.sender.getEmail()+"-"+this.subject;
    }

    private String getDateFormat() {
        Date date= Calendar.getInstance().getTime();
        DateFormat dateFormat= new SimpleDateFormat("MMM dd");

        return dateFormat.format(date);
    }

    private String getTimeFormat() {
        Date date= Calendar.getInstance().getTime();
        DateFormat dateFormat= new SimpleDateFormat("hh:mm");

        return dateFormat.format(date);
    }

    public User getSender() { return this.sender; }
    public String getSubject() { return this.subject; }
    public String getMessage() { return this.message; }
    public String getDate() { return this.date; }
    public String getDateTime() {return this.date+", "+this.time; }
    public boolean isStarred() { return this.starred; }
    public void setStarred(boolean starred) { this.starred = starred; }
    public boolean isDeleted() { return deleted; }
    public void setDeleted(boolean deleted) { this.deleted = deleted; }
}
