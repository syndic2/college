package com.example.mdpm7_6615;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MasterUserFragment extends Fragment {
    RecyclerView rvUser;
    List<User> users;
    UserAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_masteruser, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvUser= view.findViewById(R.id.rvUser);
        users= new ArrayList<>();
        new GetAllTask().execute();
        adapter= new UserAdapter(users);

        rvUser.setHasFixedSize(true);
        rvUser.setLayoutManager(new LinearLayoutManager(getContext()));
        rvUser.setAdapter(adapter);

        adapter.setOnClickCallback(new UserAdapter.OnClickCallback() {
            @Override
            public void onBtnClick(int position) {
                if (users.get(position).getStatus() == 0) users.get(position).setStatus(1);
                else if (users.get(position).getStatus() == 1) users.get(position).setStatus(0);

                new UpdateTask().execute(users.get(position));
            }
        });
    }

    private class UpdateTask extends  AsyncTask<User, Void, Void> {
        @Override
        protected Void doInBackground(User... users) {
            LoginRegisterActivity.db.userDAO().update(users[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            new GetAllTask().execute();
        }
    }

    private class GetAllTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
           if (!LoginRegisterActivity.db.userDAO().getAllUser().isEmpty()) {
               users.clear();
               users.addAll(LoginRegisterActivity.db.userDAO().getAllUser());
           }

           return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            adapter.notifyDataSetChanged();
        }
    }
}
