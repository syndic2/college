package com.example.mdpm7_6615;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface TransactionDAO {
    @Insert
    void insert(Transaction transaction);

    @Delete
    void delete(Transaction transaction);

    @Query("SELECT * FROM trans WHERE user = :username AND (type = 'in' OR type = 'out')")
    List<Transaction> getAllTransactionFrom(String username);

    @Query("SELECT * FROM trans WHERE user = :username AND (type = 'in' OR type = 'request')")
    List<Transaction> getAllFeedsTransactionFrom(String username);

    @Query("SELECT * FROM trans WHERE user = :username AND (current = :search OR other = :search)")
    List<Transaction> getAllTransactionByUsername(String username, String search);

    @Query("SELECT * FROM trans WHERE user = :username AND type = :type")
    List<Transaction> getAllTransactionByType(String username, String type);

    @Query("SELECT * FROM trans WHERE user = :username AND (current = :search OR other = :search) AND type = :type")
    List<Transaction> getAllTransactionByTypeWithUsername(String username, String search, String type);

}

