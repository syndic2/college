package com.example.mdpm7_6615;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

public class TransferFragment extends Fragment {
    RadioButton rbTransfer, rbRequest;
    EditText edtNominal, edtDestination;
    Button btnSubmit;
    List<User> users;
    User logged;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_transfer, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rbTransfer= view.findViewById(R.id.rbTransfer);
        rbRequest= view.findViewById(R.id.rbRequest);
        edtNominal= view.findViewById(R.id.edtNominal);
        edtDestination= view.findViewById(R.id.edtDestination);
        btnSubmit= view.findViewById(R.id.btnSubmit);
        users= new ArrayList<>();
        new GetAllTask().execute();
        logged= (User) getArguments().getSerializable("logged");

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String type= "";

                if (rbTransfer.isChecked()) type= "out";
                else if (rbRequest.isChecked()) type= "request";

                if (!type.isEmpty() && !edtNominal.getText().toString().isEmpty() && !edtDestination.getText().toString().isEmpty()) {
                    int nominal= Integer.parseInt(edtNominal.getText().toString());
                    User other= checkExist(edtDestination.getText().toString());

                    if (type.equals("out")) {
                        if (logged.getBalance() >= nominal) {
                            if (other != null) {
                                logged.setBalance(-nominal);
                                other.setBalance(nominal);
                                new UpdateTask().execute(logged);
                                new UpdateTask().execute(other);
                                new InsertTask().execute(new Transaction(logged.getUsername(), logged.getName(), other.getName(), nominal, "out"));
                                new InsertTask().execute(new Transaction(other.getUsername(), other.getName(), logged.getName(), nominal, "in"));
                            } else Toast.makeText(getContext(), "ID not found!", Toast.LENGTH_SHORT).show();
                        } else Toast.makeText(getContext(), "Your balance not enough!", Toast.LENGTH_SHORT).show();
                    } else if (type.equals("request")) {
                        if (other != null) {
                            new InsertTask().execute(new Transaction(other.getUsername(), other.getName(), logged.getName(), nominal, "request"));
                        } else Toast.makeText(getContext(), "ID not found!", Toast.LENGTH_SHORT).show();
                    }
                } else Toast.makeText(getContext(), "All field must not empty!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private User checkExist(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }

        return null;
    }

    private class InsertTask extends AsyncTask<Transaction, Void, Void> {
        @Override
        protected Void doInBackground(Transaction... transactions) {
            LoginRegisterActivity.db.transactionDAO().insert(transactions[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class UpdateTask extends AsyncTask<User, Void, Void> {
        @Override
        protected Void doInBackground(User... users) {
            LoginRegisterActivity.db.userDAO().update(users[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class GetAllTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (!LoginRegisterActivity.db.userDAO().getAllUser().isEmpty()) {
                users.clear();
                users.addAll(LoginRegisterActivity.db.userDAO().getAllUser());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }
}
