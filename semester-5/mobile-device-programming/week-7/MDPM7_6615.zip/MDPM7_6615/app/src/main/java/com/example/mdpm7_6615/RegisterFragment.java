package com.example.mdpm7_6615;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

public class RegisterFragment extends Fragment {
    EditText edtUsername, edtName, edtPIN;
    Button btnRegister;
    List<User> users;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_register, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        edtUsername= view.findViewById(R.id.edtUsername);
        edtName= view.findViewById(R.id.edtName);
        edtPIN= view.findViewById(R.id.edtPIN);
        btnRegister= view.findViewById(R.id.btnRegister);
        users= new ArrayList<>();
        new GetAllTask().execute();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username= edtUsername.getText().toString();
                String name= edtName.getText().toString();
                String PIN= edtPIN.getText().toString();
                boolean exist= false;

                if (!username.isEmpty() && !name.isEmpty() && !PIN.isEmpty()) {
                    for (User user : users) {
                        if (user.getUsername().equals(username)) {
                            exist= true;
                            break;
                        }
                    }

                    if (!exist) {
                        new InsertTask().execute(new User(name, username, PIN));
                        refreshField();
                    } else Toast.makeText(getContext(), "Username already used!", Toast.LENGTH_SHORT).show();
                } else Toast.makeText(getContext(), "Field must not empty!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void refreshField() {
        edtUsername.setText("");
        edtName.setText("");
        edtPIN.setText("");
    }

    private class InsertTask extends AsyncTask<User, Void, Void> {
        @Override
        protected Void doInBackground(User... users) {
            LoginRegisterActivity.db.userDAO().insert(users[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class GetAllTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (!LoginRegisterActivity.db.userDAO().getAllUser().isEmpty()) {
                users.clear();
                users.addAll(LoginRegisterActivity.db.userDAO().getAllUser());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) { super.onPostExecute(aVoid); }
    }
}
