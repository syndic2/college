package com.example.mdpm7_6615;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HistoryFragment extends Fragment {
    RadioButton rbIn, rbOut, rbAll;
    EditText edtUsername;
    Button btnShow;
    RecyclerView rvHistories;
    User logged;
    List<Transaction> displayHistory;
    HistoryAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rbIn= view.findViewById(R.id.rbIn);
        rbOut= view.findViewById(R.id.rbOut);
        rbAll= view.findViewById(R.id.rbAll);
        edtUsername= view.findViewById(R.id.edtUsername);
        btnShow= view.findViewById(R.id.btnShow);
        rvHistories= view.findViewById(R.id.rvHistories);
        logged= (User) getArguments().getSerializable("logged");
        displayHistory= new ArrayList<>();
        new GetAllTask().execute(logged.getUsername());
        adapter= new HistoryAdapter(displayHistory);

        rvHistories.setHasFixedSize(true);
        rvHistories.setLayoutManager(new LinearLayoutManager(getContext()));
        rvHistories.setAdapter(adapter);

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username= edtUsername.getText().toString();

                if (rbIn.isChecked()) {
                    displayHistory.clear();

                    if (!username.isEmpty()) new GetAllByTypeWithUsernameTask().execute(logged.getUsername(), username, "in");
                    else new GetAllByTypeTask().execute(logged.getUsername(), "in");
                } else if (rbOut.isChecked()) {
                    displayHistory.clear();

                    if (!username.isEmpty()) new GetAllByTypeWithUsernameTask().execute(logged.getUsername(), username, "out");
                    else new GetAllByTypeTask().execute(logged.getUsername(), "out");
                } else if (rbAll.isChecked()) {
                    displayHistory.clear();

                    if (!username.isEmpty()) new GetAllByUsernameTask().execute(logged.getUsername(), username);
                    else new GetAllTask().execute(logged.getUsername());
                }
            }
        });
    }

    private class GetAllTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... usernames) {
            if (!LoginRegisterActivity.db.transactionDAO().getAllTransactionFrom(usernames[0]).isEmpty()) {
                displayHistory.clear();
                displayHistory.addAll(LoginRegisterActivity.db.transactionDAO().getAllTransactionFrom(usernames[0]));
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            adapter.notifyDataSetChanged();
        }
    }

    private class GetAllByUsernameTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... usernames) {
            if (!LoginRegisterActivity.db.transactionDAO().getAllTransactionByUsername(usernames[0], usernames[1]).isEmpty()) {
                displayHistory.clear();
                displayHistory.addAll(LoginRegisterActivity.db.transactionDAO().getAllTransactionByUsername(usernames[0], usernames[1]));
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            adapter.notifyDataSetChanged();
        }
    }

    private class GetAllByTypeTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... strings) {
            if (!LoginRegisterActivity.db.transactionDAO().getAllTransactionByType(strings[0], strings[1]).isEmpty()) {
                displayHistory.clear();
                displayHistory.addAll(LoginRegisterActivity.db.transactionDAO().getAllTransactionByType(strings[0], strings[1]));
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            adapter.notifyDataSetChanged();
        }
    }

    private class GetAllByTypeWithUsernameTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... strings) {
            if (!LoginRegisterActivity.db.transactionDAO().getAllTransactionByTypeWithUsername(strings[0], strings[1], strings[2]).isEmpty()) {
                displayHistory.clear();
                displayHistory.addAll(LoginRegisterActivity.db.transactionDAO().getAllTransactionByTypeWithUsername(strings[0], strings[1], strings[2]));
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            adapter.notifyDataSetChanged();
        }
    }
}
