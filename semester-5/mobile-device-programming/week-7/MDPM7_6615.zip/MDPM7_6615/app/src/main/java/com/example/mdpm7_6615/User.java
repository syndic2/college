package com.example.mdpm7_6615;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

@Entity(tableName = "user")
public class User implements Serializable {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    @ColumnInfo(name = "name")
    private String name;

    @ColumnInfo(name = "username")
    private String username;

    @ColumnInfo(name = "PIN")
    private String PIN;

    @ColumnInfo(name = "balance")
    private int balance;

    @ColumnInfo(name = "status")
    private int status;

    public User(String name, String username, String PIN) {
        this.name = name;
        this.username = username;
        this.PIN = PIN;
        this.status= 1;
    }

    @Override
    public String toString() { return this.username+" - "+this.PIN+" - " +this.status; }

    public String getCurrencyFormat() {
        DecimalFormat currency= (DecimalFormat) DecimalFormat.getCurrencyInstance();
        DecimalFormatSymbols rupiah= new DecimalFormatSymbols();

        rupiah.setCurrencySymbol("Rp ");
        rupiah.setMonetaryDecimalSeparator(',');
        rupiah.setGroupingSeparator('.');
        currency.setDecimalFormatSymbols(rupiah);

        return currency.format(this.balance);
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getUsername() { return username; }
    public String getPIN() { return PIN; }
    public int getBalance() { return balance; }
    public int getStatus() { return status; }

    public void setId(int id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setUsername(String username) { this.username = username; }
    public void setPIN(String PIN) { this.PIN = PIN; }
    public void setBalance(int balance) { this.balance += balance; }
    public void setStatus(int status) { this.status = status; }
}
