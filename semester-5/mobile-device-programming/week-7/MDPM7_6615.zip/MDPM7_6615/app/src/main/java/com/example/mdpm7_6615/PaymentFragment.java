package com.example.mdpm7_6615;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.room.Update;

import java.util.ArrayList;
import java.util.List;

public class PaymentFragment extends Fragment {
    Spinner spinMerchant;
    EditText edtNominal;
    Button btnPay;
    List<Merchant> merchants;
    ArrayAdapter adapter;
    User logged;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_payment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        spinMerchant= view.findViewById(R.id.spinMerchant);
        edtNominal= view.findViewById(R.id.edtNominal);
        btnPay= view.findViewById(R.id.btnPay);
        merchants= new ArrayList<>();
        new GetAllTask().execute();
        adapter= new ArrayAdapter(getContext(), android.R.layout.simple_spinner_dropdown_item, merchants);
        logged= (User) getArguments().getSerializable("logged");

        spinMerchant.setAdapter(adapter);
        spinMerchant.setSelection(0);

        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Merchant merchant= (Merchant) spinMerchant.getSelectedItem();
                int nominal= 0;

                if (merchant != null && !edtNominal.getText().toString().isEmpty()) {
                    nominal= Integer.parseInt(edtNominal.getText().toString());

                    if (logged.getBalance() > nominal) {
                        logged.setBalance(-nominal);
                        new UpdateTask().execute(logged);
                        new InsertTask().execute(new Transaction(logged.getUsername(), logged.getName(), merchant.getName(), nominal, "out", true));
                    } else Toast.makeText(getContext(), "Your balance not enough!", Toast.LENGTH_SHORT).show();
                } else Toast.makeText(getContext(), "Field must not empty!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private class InsertTask extends AsyncTask<Transaction, Void, Void> {
        @Override
        protected Void doInBackground(Transaction... transactions) {
            LoginRegisterActivity.db.transactionDAO().insert(transactions[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class UpdateTask extends  AsyncTask<User, Void, Void> {
        @Override
        protected Void doInBackground(User... users) {
            LoginRegisterActivity.db.userDAO().update(users[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class GetAllTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (!LoginRegisterActivity.db.merchantDAO().getAllMerchant().isEmpty()) {
                merchants.clear();
                merchants.addAll(LoginRegisterActivity.db.merchantDAO().getAllMerchant());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            adapter.notifyDataSetChanged();
        }
    }
}
