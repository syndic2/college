package com.example.mdpm7_6615;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

public class MasterMerchantFragment extends Fragment {
    EditText edtName;
    Button btnAdd;
    ListView lvMerchant;
    List<Merchant> merchants;
    ArrayAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_mastermerchant, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        edtName= view.findViewById(R.id.edtName);
        btnAdd= view.findViewById(R.id.btnAdd);
        lvMerchant= view.findViewById(R.id.lvMerchant);
        merchants= new ArrayList<>();
        new GetAllTask().execute();
        adapter= new ArrayAdapter(getContext(), android.R.layout.simple_list_item_1, merchants);

        lvMerchant.setAdapter(adapter);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name= edtName.getText().toString();

                if (!name.isEmpty()) {
                    new InsertTask().execute(new Merchant(name));
                } else {
                    Toast.makeText(getContext(), "Field must not empty!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        lvMerchant.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                onCreatePopUpMenu(view, i);

                return false;
            }
        });
    }

    private void onCreatePopUpMenu(View view, final int position) {
        PopupMenu popup= new PopupMenu(getContext(), view);
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.menuDelete) {
                    new DeleteTask().execute(merchants.get(position));
                }

                return false;
            }
        });

        popup.inflate(R.menu.context_menu);
        popup.show();
    }

    private class InsertTask extends AsyncTask<Merchant, Void, Void> {
        @Override
        protected Void doInBackground(Merchant... merchants) {
            LoginRegisterActivity.db.merchantDAO().insert(merchants[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            new GetAllTask().execute();
        }
    }

    private class DeleteTask extends AsyncTask<Merchant, Void, Void> {
        @Override
        protected Void doInBackground(Merchant... merchants) {
            LoginRegisterActivity.db.merchantDAO().delete(merchants[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            new GetAllTask().execute();
        }
    }

    private class GetAllTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (!LoginRegisterActivity.db.merchantDAO().getAllMerchant().isEmpty()) {
                merchants.clear();
                merchants.addAll(LoginRegisterActivity.db.merchantDAO().getAllMerchant());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            adapter.notifyDataSetChanged();
        }
    }
}
