package com.example.mdpm7_6615;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FeedsAdapter extends RecyclerView.Adapter<FeedsAdapter.FeedsViewHolder> {
    private List<Transaction> feeds;
    private OnItemClickCallback onItemClickCallback;

    public FeedsAdapter(List<Transaction> feeds) {
        this.feeds = feeds;
    }

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) { this.onItemClickCallback = onItemClickCallback; }

    @NonNull
    @Override
    public FeedsAdapter.FeedsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new FeedsAdapter.FeedsViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_feeds, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull FeedsAdapter.FeedsViewHolder holder, final int position) {
        Transaction feed= this.feeds.get(position);

        if (feed.getType().equals("in")) {
            holder.tvDescription.setText(feed.getOther()+" telah mengirimkan dana sebesar "+feed.getCurrencyFormat());
            holder.linearContainer.setBackgroundColor(Color.GREEN);
            holder.btnSend.setVisibility(View.INVISIBLE);
        } else if (feed.getType().equals("request")) {
            holder.tvDescription.setText(feed.getOther()+" telah meminta dana sebesar "+feed.getCurrencyFormat());
            holder.linearContainer.setBackgroundColor(Color.YELLOW);
            holder.btnSend.setVisibility(View.VISIBLE);
        }

        holder.tvDateTime.setText(feed.getDateTime());

        holder.btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onItemClickCallback != null) {
                    onItemClickCallback.onItemClicked(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.feeds.size();
    }

    public class FeedsViewHolder extends RecyclerView.ViewHolder {
        LinearLayout linearContainer;
        TextView tvDescription, tvDateTime;
        Button btnSend;

        public FeedsViewHolder(@NonNull View itemView) {
            super(itemView);

            this.linearContainer= itemView.findViewById(R.id.linearContainer);
            this.tvDescription= itemView.findViewById(R.id.tvDescription);
            this.tvDateTime= itemView.findViewById(R.id.tvDateTime);
            this.btnSend= itemView.findViewById(R.id.btnSend);
        }
    }

    public interface OnItemClickCallback { void onItemClicked(int position); }
}
