package com.example.mdpm7_6615;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>{
    private List<Transaction> histories;

    public HistoryAdapter(List<Transaction> histories) {
        this.histories = histories;
    }

    @NonNull
    @Override
    public HistoryAdapter.HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new HistoryViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_history, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.HistoryViewHolder holder, int position) {
        Transaction history= histories.get(position);

        holder.tvDateTime.setText(history.getDateTime());
        holder.tvMoney.setText(history.getCurrencyFormat());

        if (history.getType().equals("in")) {
            holder.tvDescription.setText("Uang masuk dari "+history.getOther());
            holder.tvCode.setText("CR");
            holder.tvMoney.setTextColor(Color.GREEN);
            holder.tvCode.setTextColor(Color.GREEN);
        } else if (history.getType().equals("out")) {
            if (history.isPayment()) holder.tvDescription.setText("Payment ke "+history.getOther());
            else holder.tvDescription.setText("Transfer ke "+history.getOther());

            holder.tvCode.setText("DB");
            holder.tvMoney.setTextColor(Color.RED);
            holder.tvCode.setTextColor(Color.RED);
        }
    }

    @Override
    public int getItemCount() {
        return this.histories.size();
    }

    public class HistoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvDateTime, tvMoney, tvDescription, tvCode;

        public HistoryViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvDateTime= itemView.findViewById(R.id.tvDateTime);
            this.tvMoney= itemView.findViewById(R.id.tvMoney);
            this.tvDescription= itemView.findViewById(R.id.tvDescription);
            this.tvCode= itemView.findViewById(R.id.tvCode);
        }
    }
}
