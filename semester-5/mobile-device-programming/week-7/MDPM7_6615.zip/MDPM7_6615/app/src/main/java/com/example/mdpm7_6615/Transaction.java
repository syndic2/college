package com.example.mdpm7_6615;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Entity(tableName = "trans")
public class Transaction {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    @ColumnInfo(name = "user")
    private String user;

    @ColumnInfo(name = "current")
    private String current;

    @ColumnInfo(name = "other")
    private String other;

    @ColumnInfo(name = "nominal")
    private int nominal;

    @ColumnInfo(name = "type")
    private String type;

    @ColumnInfo(name = "dateTime")
    private String dateTime;

    @ColumnInfo(name = "payment")
    private boolean payment;

    public Transaction(String user, String current, String other, int nominal, String type) {
        this.user= user;
        this.current= current;
        this.other= other;
        this.nominal= nominal;
        this.type= type;
        this.dateTime= this.getDateTimeFormat();
    }

    @Ignore
    public Transaction(String user, String current, String other, int nominal, String type, boolean payment) {
        this.user= user;
        this.current= current;
        this.other= other;
        this.nominal= nominal;
        this.type= type;
        this.dateTime= this.getDateTimeFormat();
        this.payment= payment;
    }

    @Override
    public String toString() {
        return this.current+" - "+this.other+" - "+this.nominal+" - "+this.type;
    }

    public String getCurrencyFormat() {
        DecimalFormat currency= (DecimalFormat) DecimalFormat.getCurrencyInstance();
        DecimalFormatSymbols rupiah= new DecimalFormatSymbols();

        rupiah.setCurrencySymbol("Rp ");
        rupiah.setMonetaryDecimalSeparator(',');
        rupiah.setGroupingSeparator('.');
        currency.setDecimalFormatSymbols(rupiah);

        return currency.format(this.nominal);
    }

    private String getDateTimeFormat() {
        Date date= Calendar.getInstance().getTime();
        DateFormat formatter= new SimpleDateFormat("dd MMM, hh:mm");

        return formatter.format(date);
    }

    public int getId() { return id; }
    public String getUser() { return user; }
    public String getCurrent() { return current; }
    public String getOther() { return other; }
    public int getNominal() { return nominal; }
    public String getType() { return type; }
    public String getDateTime() { return dateTime; }
    public boolean isPayment() { return payment; }

    public void setId(int id) { this.id = id; }
    public void setUser(String user) { this.user = user; }
    public void setCurrent(String current) { this.current = current; }
    public void setOther(String other) { this.other = other; }
    public void setNominal(int nominal) { this.nominal = nominal; }
    public void setType(String type) { this.type = type; }
    public void setDateTime(String dateTime) { this.dateTime = dateTime; }
    public void setPayment(boolean payment) { this.payment = payment; }
}
