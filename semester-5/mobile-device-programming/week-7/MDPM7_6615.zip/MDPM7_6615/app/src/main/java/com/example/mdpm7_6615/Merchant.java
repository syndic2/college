package com.example.mdpm7_6615;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "merchant")
public class Merchant {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    @ColumnInfo(name = "name")
    private String name;

    @ColumnInfo(name = "balance")
    private int balance;

    public Merchant(String name) {
        this.name = name;
        this.balance = balance;
    }

    @Override
    public String toString() { return this.name; }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getBalance() { return balance; }

    public void setId(int id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setBalance(int balance) { this.balance = balance; }
}
