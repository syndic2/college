package com.example.mdpm7_6615;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.room.Room;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.Toast;

public class LoginRegisterActivity extends AppCompatActivity {
    FrameLayout frameContainer;
    public static AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginregister);

        frameContainer= findViewById(R.id.frameContainer);
        db= Room.databaseBuilder(this, AppDatabase.class, "MDPM7").build();

        showFragment(new LoginFragment());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        menu.findItem(R.id.menuLogout).setVisible(false);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuLogin:
                showFragment(new LoginFragment());
                break;
            case R.id.menuRegister:
                showFragment(new RegisterFragment());
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showFragment(Fragment fragment) {
        FragmentTransaction trans= getSupportFragmentManager().beginTransaction();
        trans.replace(R.id.frameContainer, fragment);
        trans.commit();
    }
}
