package com.example.mdpm7_6615;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class MyAccountFragment extends Fragment {
    TextView tvUsername;
    EditText edtName, edtNewPIN, edtOldPIN;
    Button btnSave;
    User logged;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_myaccount, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvUsername= view.findViewById(R.id.tvUsername);
        edtName= view.findViewById(R.id.edtName);
        edtNewPIN= view.findViewById(R.id.edtNewPIN);
        edtOldPIN= view.findViewById(R.id.edtOldPIN);
        btnSave= view.findViewById(R.id.btnSave);
        logged= (User) getArguments().getSerializable("logged");

        if (logged != null) {
            tvUsername.setText(logged.getUsername());
            edtName.setText(logged.getName());
        }

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name= edtName.getText().toString();
                String newPIN= edtNewPIN.getText().toString();
                String oldPIN= edtOldPIN.getText().toString();

                if (!newPIN.isEmpty() && !oldPIN.isEmpty()) {
                    if (logged.getPIN().equals(oldPIN)) logged.setPIN(newPIN);
                    else Toast.makeText(getContext(), "Wrong old PIN!", Toast.LENGTH_SHORT).show();
                }

                if (!name.isEmpty()) logged.setName(name);

                new UpdateTask().execute(logged);
            }
        });
    }

    private class UpdateTask extends AsyncTask<User, Void, Void> {
        @Override
        protected Void doInBackground(User... users) {
            LoginRegisterActivity.db.userDAO().update(users[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }
}
