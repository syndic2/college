package com.example.mdpm7_6615;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {User.class, Merchant.class, Transaction.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract UserDAO userDAO();
    public abstract MerchantDAO merchantDAO();
    public abstract  TransactionDAO transactionDAO();
}
