package com.example.mdpm7_6615;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    TextView tvLogged, tvBalance;
    EditText edtAmount;
    Button btnTopUp;
    RecyclerView rvFeeds;
    List<Transaction> feeds;
    List<User> users;
    User logged;
    FeedsAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvLogged= view.findViewById(R.id.tvLogged);
        tvBalance= view.findViewById(R.id.tvBalance);
        edtAmount= view.findViewById(R.id.edtAmount);
        btnTopUp= view.findViewById(R.id.btnTopUp);
        rvFeeds= view.findViewById(R.id.rvFeeds);
        feeds= new ArrayList<>();
        users= new ArrayList<>();
        logged= (User) getArguments().getSerializable("logged");
        new GetAllUserTask().execute();
        new GetAllTransactionTask().execute(logged.getUsername());
        adapter= new FeedsAdapter(feeds);

        rvFeeds.setHasFixedSize(true);
        rvFeeds.setLayoutManager(new LinearLayoutManager(getContext()));
        rvFeeds.setAdapter(adapter);

        if (logged != null) {
            tvLogged.setText("Welcome, "+logged.getName());
            tvBalance.setText("Your Balance: "+logged.getCurrencyFormat());

            Toast.makeText(getContext(), logged.toString(), Toast.LENGTH_SHORT).show();
        }

        btnTopUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int amount= 0;

                if (!edtAmount.getText().toString().isEmpty()) {
                    amount= Integer.parseInt(edtAmount.getText().toString());

                    logged.setBalance(amount);
                    new UpdateTask().execute(logged);
                    tvBalance.setText("Your Balance: "+logged.getCurrencyFormat());
                } else Toast.makeText(getContext(), "Field must not empty!", Toast.LENGTH_SHORT).show();
            }
        });

        adapter.setOnItemClickCallback(new FeedsAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(int position) {
                User other= getUser(feeds.get(position).getOther());

                if (other != null) {
                    logged.setBalance(-feeds.get(position).getNominal());
                    other.setBalance(feeds.get(position).getNominal());
                    new UpdateTask().execute(logged);
                    new UpdateTask().execute(other);
                    new InsertTask().execute(new Transaction(logged.getUsername(), logged.getName(), other.getName(), feeds.get(position).getNominal(), "out"));
                    new InsertTask().execute(new Transaction(other.getUsername(), other.getName(), logged.getName(), feeds.get(position).getNominal(), "in"));
                    new DeleteTask().execute(feeds.get(position));

                    tvBalance.setText("Your Balance: "+logged.getCurrencyFormat());
                }
            }
        });
    }

    private User getUser(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }

        return null;
    }

    private class InsertTask extends AsyncTask<Transaction, Void, Void> {
        @Override
        protected Void doInBackground(Transaction... transactions) {
            LoginRegisterActivity.db.transactionDAO().insert(transactions[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class DeleteTask extends AsyncTask<Transaction, Void, Void> {
        @Override
        protected Void doInBackground(Transaction... transactions) {
            LoginRegisterActivity.db.transactionDAO().delete(transactions[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            new GetAllTransactionTask();
        }
    }

    private class UpdateTask extends AsyncTask<User, Void, Void> {
        @Override
        protected Void doInBackground(User... users) {
            LoginRegisterActivity.db.userDAO().update(users[0]);

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class GetAllUserTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (!LoginRegisterActivity.db.userDAO().getAllUser().isEmpty()) {
                users.clear();
                users.addAll(LoginRegisterActivity.db.userDAO().getAllUser());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class GetAllTransactionTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... usernames) {
            if (!LoginRegisterActivity.db.transactionDAO().getAllFeedsTransactionFrom(usernames[0]).isEmpty()) {
                feeds.clear();
                feeds.addAll(LoginRegisterActivity.db.transactionDAO().getAllFeedsTransactionFrom(usernames[0]));
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            adapter.notifyDataSetChanged();
        }
    }
}
