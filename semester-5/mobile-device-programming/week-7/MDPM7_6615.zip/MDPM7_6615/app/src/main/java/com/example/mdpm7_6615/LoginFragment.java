package com.example.mdpm7_6615;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

public class LoginFragment extends Fragment {
    EditText edtUsername, edtPIN;
    Button btnLogin;
    Intent page;
    List<User> users;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        edtUsername= view.findViewById(R.id.edtUsername);
        edtPIN= view.findViewById(R.id.edtPIN);
        btnLogin= view.findViewById(R.id.btnLogin);
        users= new ArrayList<>();
        new GetAllTask().execute();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username= edtUsername.getText().toString();
                String PIN= edtPIN.getText().toString();

                if (!username.isEmpty() && !PIN.isEmpty()) {

                    if (username.equals("admin") && PIN.equals("123456")) {
                        page= new Intent(getContext(), AdminActivity.class);
                        startActivity(page);
                    } else if (checkExist(username, PIN) != null) {
                        page= new Intent(getContext(), MainActivity.class);
                        page.putExtra("logged", checkExist(username, PIN));
                        startActivity(page);
                    } else Toast.makeText(getContext(), "Wrong username or PIN!", Toast.LENGTH_SHORT).show();
                } else Toast.makeText(getContext(), "Field must not empty!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private User checkExist(String username, String PIN) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPIN().equals(PIN) && user.getStatus() == 1) {
                return user;
            }
        }

        return null;
    }

    private class GetAllTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (!LoginRegisterActivity.db.userDAO().getAllUser().isEmpty()) {
                users.clear();
                users.addAll(LoginRegisterActivity.db.userDAO().getAllUser());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }
}
