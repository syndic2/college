package com.example.mdpm7_6615;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {
    private List<User> users;
    private OnClickCallback onClickCallback;

    public UserAdapter(List<User> users) {
        this.users = users;
    }

    public void setOnClickCallback(OnClickCallback onClickCallback) {
        this.onClickCallback = onClickCallback;
    }

    @NonNull
    @Override
    public UserAdapter.UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new UserAdapter.UserViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_user, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapter.UserViewHolder holder, final int position) {
        User user= users.get(position);

        holder.ivUser.setImageResource(R.drawable.account);
        holder.tvName.setText(user.getName());

        if (user.getStatus() == 0) holder.btnActive.setText("Enable");
        else if (user.getStatus() == 1) holder.btnActive.setText("Disable");

        holder.btnActive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onClickCallback != null) {
                    onClickCallback.onBtnClick(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.users.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {
        ImageView ivUser;
        TextView tvName;
        Button btnActive;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            this.ivUser= itemView.findViewById(R.id.ivUser);
            this.tvName= itemView.findViewById(R.id.tvName);
            this.btnActive= itemView.findViewById(R.id.btnActive);
        }
    }

    public interface OnClickCallback { void onBtnClick(int position); }
}
