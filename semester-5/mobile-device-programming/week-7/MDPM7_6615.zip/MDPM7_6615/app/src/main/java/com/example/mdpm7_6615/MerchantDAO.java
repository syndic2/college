package com.example.mdpm7_6615;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface MerchantDAO {
    @Insert
    void insert(Merchant merchant);

    @Delete
    void delete(Merchant merchant);

    @Query("SELECT * FROM merchant")
    List<Merchant> getAllMerchant();
}
