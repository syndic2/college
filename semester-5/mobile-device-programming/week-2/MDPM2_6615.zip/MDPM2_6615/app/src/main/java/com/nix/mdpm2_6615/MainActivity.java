package com.nix.mdpm2_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Random r= new Random();
    EditText inputSoal, inputClue;
    RadioButton yes, no;
    Button play, howTo;
    Intent nextActivity;
    Bundle data;
    String soal, hint, clue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputSoal= findViewById(R.id.tEdit_inputWord);
        inputClue= findViewById(R.id.tEdit_inputClue);
        yes= findViewById(R.id.rButton_Yes);
        no= findViewById(R.id.rButton_No);
        play= findViewById(R.id.btn_Play);
        howTo= findViewById(R.id.btn_HowTo);
        hint= "";
        clue= "";

        play.setOnClickListener(this);
        howTo.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn_Play) {
            soal= inputSoal.getText().toString();
            clue= inputClue.getText().toString();

            if (yes.isChecked()) {
                if (soal.length() > 0) {
                    hint= String.valueOf(soal.charAt(r.nextInt(soal.length())));
                }
            } else if (no.isChecked()) {
                hint= "";
            }

            if (checkSoal() && checkClue()) {
                nextActivity= new Intent(MainActivity.this, GameActivity.class);
                data= new Bundle();
                data.putString("soal", soal);
                data.putString("hint", hint);
                data.putString("clue", clue);
                nextActivity.putExtras(data);
                startActivity(nextActivity);
            }
        }

        if (view.getId() == R.id.btn_HowTo) {
            String url= "https://m.wikihow.com/Play-Hangman";
            nextActivity= new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(nextActivity);
        }
    }

    private boolean checkSoal() {

        if (soal.length() > 0) {
            if (soal.length() >= 5) {
                return true;
            } else {
                Toast.makeText(
                        this,
                        "Minimum 5 character length",
                        Toast.LENGTH_SHORT
                ).show();
            }
        } else {
            Toast.makeText(
                    this,
                    "Please input question",
                    Toast.LENGTH_SHORT
            ).show();
        }

        return false;
    }

    private boolean checkClue() {

        if (!clue.equalsIgnoreCase(soal)) {
            return true;
        } else {
            Toast.makeText(
                    this,
                    "Clue must not be same as question",
                    Toast.LENGTH_SHORT
            ).show();
        }

        return false;
    }
}
