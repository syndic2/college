package com.nix.mdpm2_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;

public class GameActivity extends AppCompatActivity implements View.OnClickListener {
    TextView viewLife, viewSoal, viewClue;
    Button useHint;
    Bundle data;
    Intent nextActivity;
    ArrayList<Button> alphabets;
    ArrayList<String> tertebak;
    int life;
    String soal, jawaban, hint, clue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        viewLife= findViewById(R.id.tView_Life);
        viewSoal= findViewById(R.id.tView_Word);
        viewClue= findViewById(R.id.tView_Clue);
        useHint= findViewById(R.id.btn_UseHint);
        alphabets= new ArrayList<Button>();
        tertebak= new ArrayList<String>();
        life= 5;

        for (int i= 1; i<=26; i++) {
            String id= "btn"+i;
            int resID= getResources().getIdentifier(id, "id", getPackageName());
            Button alphabet= findViewById(resID);
            alphabet.setTextColor(Color.WHITE);
            alphabet.setBackgroundColor(Color.BLUE);
            alphabets.add(alphabet);
        }

        getBundleData();
        setViewText();

        if (!hint.equals("")) {
            useHint.setEnabled(true);
        } else {
            useHint.setEnabled(false);
        }

        for (Button alphabet : alphabets) {
            alphabet.setOnClickListener(this);
        }

        useHint.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        if (alphabets.contains((Button) view)) {
            Button clicked= (Button) view;

            if (benar(clicked)) {
                tertebak.add(clicked.getText().toString());
                clicked.setEnabled(false);
                clicked.setBackgroundColor(Color.GREEN);
            } else {
                life--;
                clicked.setEnabled(false);
                clicked.setBackgroundColor(Color.RED);
            }
        }

        if (view.getId() == R.id.btn_UseHint) {
            useHint.setEnabled(false);
            char[] unsensor= soal.toCharArray();

            tertebak.add(hint);

            for (Button btn : alphabets) {
                if (btn.getText().toString().equalsIgnoreCase(hint)) {
                    btn.setEnabled(false);
                    btn.setBackgroundColor(Color.GREEN);

                    for (int i= 0; i<jawaban.length(); i++) {
                        String check= String.valueOf(jawaban.charAt(i));

                        if (hint.equalsIgnoreCase(check)) {
                            unsensor[i]= check.charAt(0);
                        }
                    }
                }
            }

            soal= String.valueOf(unsensor);
        }

        setViewText();
        gameOver();
    }

    private void getBundleData() {

        if (getIntent().getExtras() != null) {
            data= getIntent().getExtras();
            soal= data.getString("soal");
            jawaban= data.getString("soal");
            hint= data.getString("hint");
            clue= data.getString("clue");

            String sensor= "";

            for (int i= 0; i<soal.length(); i++) {
                sensor+= "*";
            }

            soal= soal.replaceAll(soal, sensor);
        }
    }

    private boolean benar(Button btn) {
        boolean benar= false;
        char[] unsensor= soal.toCharArray();

        for (int i= 0; i<jawaban.length(); i++) {
            String check= String.valueOf(jawaban.charAt(i));

            if (btn.getText().toString().equalsIgnoreCase(check)) {
                unsensor[i]= check.charAt(0);
                benar= true;
            }
        }

        soal= String.valueOf(unsensor);

        if (benar) {
            return benar;
        }

        return false;
    }

    private void gameOver() {

        if (life <= 0) {
            life= 0;
            nextActivity= new Intent(GameActivity.this, EndActivity.class);
            data= new Bundle();
            data.putString("winner", "Player 1 Win");
            data.putString("life", life+"");
            data.putStringArrayList("tertebak", tertebak);
            data.putString("jawaban", jawaban);
            nextActivity.putExtras(data);
            startActivity(nextActivity);
        } else {
            if (soal.equals(jawaban)) {
                nextActivity= new Intent(GameActivity.this, EndActivity.class);
                data= new Bundle();
                data.putString("winner", "Player 2 Win");
                data.putString("life", life+"");
                data.putStringArrayList("tertebak", tertebak);
                data.putString("jawaban", jawaban);
                nextActivity.putExtras(data);
                startActivity(nextActivity);
            }
        }
    }

    private void setViewText() {
        viewLife.setText(life+"");
        viewSoal.setText(soal);
        viewClue.setText(clue);
    }
}
