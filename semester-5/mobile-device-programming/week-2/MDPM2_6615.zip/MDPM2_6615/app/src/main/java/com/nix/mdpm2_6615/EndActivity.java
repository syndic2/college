package com.nix.mdpm2_6615;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import java.util.ArrayList;

public class EndActivity extends AppCompatActivity {
    TextView winnerView, lifeView, tertebakView, jawabanView;
    Bundle data;
    ArrayList<String> tertebak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);

        winnerView= findViewById(R.id.tView_Winner);
        lifeView= findViewById(R.id.tView_RemainingLife);
        tertebakView= findViewById(R.id.tView_LetterGuessed);
        jawabanView= findViewById(R.id.tView_Answer);
        tertebak= new ArrayList<String>();

        if (getIntent().getExtras() != null) {
            data= getIntent().getExtras();
            winnerView.setText(data.getString("winner"));
            lifeView.setText(data.getString("life"));
            tertebak= data.getStringArrayList("tertebak");

            for (String huruf : tertebak) {
                tertebakView.append(huruf+", ");
            }

            jawabanView.setText(data.getString("jawaban"));
        }
    }
}
