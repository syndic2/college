package com.example.mdpm6_6615;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class FeedsAdapter extends RecyclerView.Adapter<FeedsAdapter.FeedsViewHolder> {
    private ArrayList<Transaction> feeds;
    private OnItemClickCallback onItemClickCallback;

    public FeedsAdapter(ArrayList<Transaction> feeds) {
        this.feeds = feeds;
    }

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) { this.onItemClickCallback = onItemClickCallback; }

    @NonNull
    @Override
    public FeedsAdapter.FeedsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new FeedsAdapter.FeedsViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_feeds, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull FeedsAdapter.FeedsViewHolder holder, final int position) {
        Transaction transaction= this.feeds.get(position);

        if (transaction.getType().equals("send")) {
            holder.linearContainer.setBackgroundColor(Color.GREEN);
            holder.tvDescription.setText(transaction.getDestination().getName()+" telah mengirimkan dana sebesar "+transaction.getCurrencyFormat());
            holder.btnSend.setVisibility(View.INVISIBLE);
        } else if (transaction.getType().equals("request")) {
            holder.linearContainer.setBackgroundColor(Color.YELLOW);
            holder.tvDescription.setText(transaction.getDestination().getName()+" meminta dana sebesar "+transaction.getCurrencyFormat());
        }

        holder.btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onItemClickCallback != null) {
                    onItemClickCallback.onItemClicked(position);
                }
            }
        });

        holder.tvDateTime.setText(transaction.getDateTime());
    }

    @Override
    public int getItemCount() {
        return this.feeds.size();
    }

    public class FeedsViewHolder extends RecyclerView.ViewHolder {
        LinearLayout linearContainer;
        TextView tvDescription, tvDateTime;
        Button btnSend;

        public FeedsViewHolder(@NonNull View itemView) {
            super(itemView);

            this.linearContainer= itemView.findViewById(R.id.linearContainer);
            this.tvDescription= itemView.findViewById(R.id.tvDescription);
            this.tvDateTime= itemView.findViewById(R.id.tvDateTime);
            this.btnSend= itemView.findViewById(R.id.btnSend);
        }
    }

    public interface OnItemClickCallback { void onItemClicked(int position); }
}
