package com.example.mdpm6_6615;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>{
    private ArrayList<Transaction> histories;

    public HistoryAdapter(ArrayList<Transaction> histories) {
        this.histories = histories;
    }

    @NonNull
    @Override
    public HistoryAdapter.HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new HistoryViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_history, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.HistoryViewHolder holder, int position) {
        Transaction transaction= this.histories.get(position);

        holder.tvDateTime.setText(transaction.getDateTime());
        holder.tvMoney.setText(transaction.getCurrencyFormat());

        if (transaction.getType().equals("send")) {
            holder.tvDescription.setText("Transfer ke "+transaction.getDestination().getName());
            holder.tvCode.setText("DB");
            holder.tvMoney.setTextColor(Color.RED);
            holder.tvCode.setTextColor(Color.RED);
        } else if (transaction.getType().equals("request")) {
            holder.tvDescription.setText("Uang masuk dari "+transaction.getDestination().getName());
            holder.tvCode.setText("CR");
            holder.tvMoney.setTextColor(Color.GREEN);
            holder.tvCode.setTextColor(Color.GREEN);
        }
    }

    @Override
    public int getItemCount() {
        return this.histories.size();
    }

    public class HistoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvDateTime, tvMoney, tvDescription, tvCode;

        public HistoryViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvDateTime= itemView.findViewById(R.id.tvDateTime);
            this.tvMoney= itemView.findViewById(R.id.tvMoney);
            this.tvDescription= itemView.findViewById(R.id.tvDescription);
            this.tvCode= itemView.findViewById(R.id.tvCode);
        }
    }
}
