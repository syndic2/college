package com.example.mdpm6_6615;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.util.ArrayList;

public class LoginRegisterActivity extends AppCompatActivity {
    FrameLayout frameContainer;
    Intent page;
    ArrayList<User> users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginregister);

        frameContainer= findViewById(R.id.frameContainer);
        users= new ArrayList<>();

        getExtrasData();
        showFragment(new LoginFragment());

        Toast.makeText(this, users.toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);

        menu.findItem(R.id.menuLogout).setVisible(false);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuLogin:
                showFragment(new LoginFragment());
                break;
            case R.id.menuRegister:
                showFragment(new RegisterFragment());
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showFragment(Fragment fragment) {
        Bundle argument= new Bundle();
        argument.putSerializable("users", users);

        FragmentTransaction trans= getSupportFragmentManager().beginTransaction();
        fragment.setArguments(argument);

        trans.replace(R.id.frameContainer, fragment);
        trans.commit();
    }

    private void getExtrasData() {
        page= getIntent();

        if (page.hasExtra("users")) {
            users= (ArrayList<User>) page.getSerializableExtra("users");

            Toast.makeText(this, users.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}
