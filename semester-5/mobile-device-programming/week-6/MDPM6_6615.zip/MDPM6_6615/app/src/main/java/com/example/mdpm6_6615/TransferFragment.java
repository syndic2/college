package com.example.mdpm6_6615;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

public class TransferFragment extends Fragment {
    RadioButton rbTransfer, rbRequest;
    EditText edtNominal, edtDestination;
    Button btnSubmit;
    ArrayList<User> users;
    int logged;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_transfer, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rbTransfer= view.findViewById(R.id.rbTransfer);
        rbRequest= view.findViewById(R.id.rbRequest);
        edtNominal= view.findViewById(R.id.edtNominal);
        edtDestination= view.findViewById(R.id.edtDestination);
        btnSubmit= view.findViewById(R.id.btnSubmit);
        users= (ArrayList<User>) getArguments().getSerializable("users");
        logged= getArguments().getInt("logged", -1);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String type= "";

                if (rbTransfer.isChecked()) type= "send";
                else if (rbRequest.isChecked()) type= "request";

                if (!type.isEmpty() && !edtNominal.getText().toString().isEmpty() && !edtDestination.getText().toString().isEmpty()) {
                    User destination= null;

                    for (User user : users) {
                        if (user.getName().equals(edtDestination.getText().toString()) && !user.getName().equals(users.get(logged).getName())) {
                            destination= user;
                            break;
                        }
                    }

                    if (destination != null) {
                        int nominal= Integer.parseInt(edtNominal.getText().toString());

                        if (type.equals("send")) {
                            if (users.get(logged).getBalance() > 0) {
                                users.get(logged).setBalance(-nominal);
                                users.get(logged).setHistory(new Transaction(destination, nominal, type));
                                destination.setBalance(nominal);
                                destination.setFeeds(new Transaction(users.get(logged), nominal, type));
                                destination.setHistory(new Transaction(users.get(logged), nominal, "request"));
                                Toast.makeText(getContext(), "Transfer to "+destination.getName()+" success!", Toast.LENGTH_SHORT).show();
                            } else Toast.makeText(getContext(), "Not enough balance!", Toast.LENGTH_SHORT).show();
                        } else if (type.equals("request")) {
                            destination.setFeeds(new Transaction(users.get(logged), nominal, type));
                            Toast.makeText(getContext(), "Requested to "+destination.getName(), Toast.LENGTH_SHORT).show();
                        }
                    } else Toast.makeText(getContext(), "ID not found!", Toast.LENGTH_SHORT).show();
                } else Toast.makeText(getContext(), "All field must not empty!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
