package com.example.mdpm6_6615;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Transaction implements Serializable {
    private User destination;
    private int nominal;
    private String type, dateTime;

    public Transaction(User destination, int nominal, String type) {
        this.destination = destination;
        this.nominal = nominal;
        this.type = type;
        this.dateTime= this.getDateTimeFormat();
    }

    @Override
    public String toString() {
        return this.destination+" - "+this.nominal+" - "+this.type;
    }

    public String getCurrencyFormat() {
        DecimalFormat currency= (DecimalFormat) DecimalFormat.getCurrencyInstance();
        DecimalFormatSymbols rupiah= new DecimalFormatSymbols();

        rupiah.setCurrencySymbol("Rp ");
        rupiah.setMonetaryDecimalSeparator(',');
        rupiah.setGroupingSeparator('.');
        currency.setDecimalFormatSymbols(rupiah);

        return currency.format(this.nominal);
    }

    private String getDateTimeFormat() {
        Date date= Calendar.getInstance().getTime();
        DateFormat formatter= new SimpleDateFormat("dd MMM, hh:mm");

        return formatter.format(date);
    }


    public User getDestination() { return this.destination; }
    public int getNominal() { return this.nominal; }
    public String getType() { return this.type; }
    public String getDateTime() { return this.dateTime; }

}
