package com.example.mdpm6_6615;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;

public class User implements Serializable {
    private String name, username, PIN;
    private int balance;
    private ArrayList<Transaction> feeds, histories;

    public User(String name, String username, String PIN) {
        this.name = name;
        this.username = username;
        this.PIN = PIN;
        this.feeds= new ArrayList<>();
        this.histories= new ArrayList<>();
    }

    @Override
    public String toString() {
        return this.username+" - "+this.PIN;
    }

    public String getCurrencyFormat() {
        DecimalFormat currency= (DecimalFormat) DecimalFormat.getCurrencyInstance();
        DecimalFormatSymbols rupiah= new DecimalFormatSymbols();

        rupiah.setCurrencySymbol("Rp ");
        rupiah.setMonetaryDecimalSeparator(',');
        rupiah.setGroupingSeparator('.');
        currency.setDecimalFormatSymbols(rupiah);

        return currency.format(this.balance);
    }

    public String getName() { return this.name; }
    public String getUsername() { return this.username; }
    public String getPIN() { return this.PIN; }
    public int getBalance() { return this.balance; }
    public void setBalance(int balance) { this.balance += balance; }
    public ArrayList<Transaction> getFeeds() { return this.feeds; }
    public void setFeeds(Transaction feed) { this.feeds.add(feed); }
    public ArrayList<Transaction> getHistories() { return this.histories; }
    public void setHistory(Transaction history) { this.histories.add(history); }
}
