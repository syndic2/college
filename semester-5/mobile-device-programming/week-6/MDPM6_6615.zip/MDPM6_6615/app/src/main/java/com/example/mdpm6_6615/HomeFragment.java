package com.example.mdpm6_6615;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class HomeFragment extends Fragment {
    TextView tvLogged, tvBalance;
    EditText edtAmount;
    Button btnTopUp;
    RecyclerView rvFeeds;
    ArrayList<User> users;
    FeedsAdapter adapter;
    int logged;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvLogged= view.findViewById(R.id.tvLogged);
        tvBalance= view.findViewById(R.id.tvBalance);
        edtAmount= view.findViewById(R.id.edtAmount);
        btnTopUp= view.findViewById(R.id.btnTopUp);
        rvFeeds= view.findViewById(R.id.rvFeeds);
        users= (ArrayList<User>) getArguments().getSerializable("users");
        logged= getArguments().getInt("logged", -1);
        adapter= new FeedsAdapter(users.get(logged).getFeeds());

        rvFeeds.setHasFixedSize(true);
        rvFeeds.setLayoutManager(new LinearLayoutManager(getContext()));
        rvFeeds.setAdapter(adapter);

        tvLogged.setText("Welcome, "+users.get(logged).getName()+"!");
        tvBalance.setText("Your Balance: "+users.get(logged).getCurrencyFormat());

        btnTopUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int amount= 0;

                if (!edtAmount.getText().toString().isEmpty()) amount= Integer.parseInt(edtAmount.getText().toString());

                if (amount > 0) {
                    users.get(logged).setBalance(amount);
                    tvBalance.setText("Your Balance: "+users.get(logged).getCurrencyFormat());

                    Toast.makeText(getContext(), "To up of "+amount+" success!", Toast.LENGTH_SHORT).show();
                } else Toast.makeText(getContext(), "Field must not empty!", Toast.LENGTH_SHORT).show();
            }
        });

        adapter.setOnItemClickCallback(new FeedsAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(int position) {
                User destination= null;

                for (User user : users) {
                    if (user.getUsername().equals(users.get(logged).getFeeds().get(position).getDestination().getUsername())) {
                        destination= user;
                        break;
                    }
                }

                if (destination != null) {
                    if (users.get(logged).getBalance() > 0) {
                        users.get(logged).setBalance(-users.get(logged).getFeeds().get(position).getNominal());
                        users.get(logged).setHistory(new Transaction(destination, users.get(logged).getFeeds().get(position).getNominal(), "send"));
                        destination.setBalance(users.get(logged).getFeeds().get(position).getNominal());
                        destination.setFeeds(new Transaction(users.get(logged), users.get(logged).getFeeds().get(position).getNominal(), "send"));
                        destination.setHistory(new Transaction(users.get(logged), users.get(logged).getFeeds().get(position).getNominal(), "request"));
                        users.get(logged).getFeeds().remove(position);
                        adapter.notifyDataSetChanged();
                        tvBalance.setText("Your Balance: "+users.get(logged).getBalance());
                    } else Toast.makeText(getContext(), "Not enough balance!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
