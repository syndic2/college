package com.example.mdpm6_6615;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.Toast;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    FrameLayout frameContainer;
    BottomNavigationView bottomNav;
    Intent page;
    ArrayList<User> users;
    int logged;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frameContainer= findViewById(R.id.frameContainer);
        bottomNav= findViewById(R.id.bottomNav);

        getExtrasData();
        showFragment(new HomeFragment());

        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.menuHome:
                        showFragment(new HomeFragment());
                        break;
                    case R.id.menuHistory:
                        showFragment(new HistoryFragment());
                        break;
                    case R.id.menuTransfer:
                        showFragment(new TransferFragment());
                        break;
                }

                return true;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        menu.findItem(R.id.menuLogin).setVisible(false);
        menu.findItem(R.id.menuRegister).setVisible(false);
        menu.findItem(R.id.menuLogout).setVisible(true);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menuLogout) {
            page= new Intent(MainActivity.this, LoginRegisterActivity.class);
            page.putExtra("users", users);
            startActivity(page);
        }

        return super.onOptionsItemSelected(item);
    }

    private void getExtrasData() {
        page= getIntent();

        if (page.hasExtra("users")) {
            users= (ArrayList<User>) page.getSerializableExtra("users");

            Toast.makeText(this, users.toString(), Toast.LENGTH_SHORT).show();
        }

        if (page.hasExtra("logged")) {
            logged= page.getIntExtra("logged", -1);

            Toast.makeText(this, logged+"", Toast.LENGTH_SHORT).show();
        }
    }

    private void showFragment(Fragment fragment) {
        Bundle argument= new Bundle();
        argument.putSerializable("users", users);
        argument.putInt("logged", logged);

        FragmentTransaction trans= getSupportFragmentManager().beginTransaction();
        fragment.setArguments(argument);

        trans.replace(R.id.frameContainer, fragment);
        trans.commit();
    }
}
