package com.example.mdpm6_6615;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

public class RegisterFragment extends Fragment {
    EditText edtUsername, edtName, edtPIN;
    Button btnRegister;
    ArrayList<User> users;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_register, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        edtUsername= view.findViewById(R.id.edtUsername);
        edtName= view.findViewById(R.id.edtName);
        edtPIN= view.findViewById(R.id.edtPIN);
        btnRegister= view.findViewById(R.id.btnRegister);
        users= (ArrayList<User>) getArguments().getSerializable("users");

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username= edtUsername.getText().toString();
                String name= edtName.getText().toString();
                String PIN= edtPIN.getText().toString();

                if (!username.isEmpty() && !name.isEmpty() && !PIN.isEmpty()) {
                    boolean exist= false;

                    for (User user : users) {
                        if (user.getUsername().equals(username)) {
                            exist= true;
                            break;
                        }
                    }

                    if (!exist) {
                        users.add(new User(name, username, PIN));
                        refreshField();
                        Toast.makeText(getContext(), "Register success!", Toast.LENGTH_SHORT).show();
                    } else Toast.makeText(getContext(), "Username already used!", Toast.LENGTH_SHORT).show();
                } else Toast.makeText(getContext(), "Field must not empty!", Toast.LENGTH_SHORT).show();
            }
        });

        Toast.makeText(view.getContext(), users.toString(), Toast.LENGTH_SHORT).show();
    }

    private void refreshField() {
        edtUsername.setText("");
        edtName.setText("");
        edtPIN.setText("");
    }
}
