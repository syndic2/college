package com.example.mdpm6_6615;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

public class LoginFragment extends Fragment {
    EditText edtUsername, edtPIN;
    Button btnLogin;
    Intent page;
    ArrayList<User> users;
    int logged;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        edtUsername= view.findViewById(R.id.edtUsername);
        edtPIN= view.findViewById(R.id.edtPIN);
        btnLogin= view.findViewById(R.id.btnLogin);
        users= (ArrayList<User>) getArguments().getSerializable("users");

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username= edtUsername.getText().toString();
                String PIN= edtPIN.getText().toString();

                if (!username.isEmpty() && !PIN.isEmpty()) {
                    logged= -1;

                    for (int i= 0; i<users.size(); i++) {
                        User user= users.get(i);

                        if (user.getUsername().equals(username) && user.getPIN().equals(PIN)) {
                            logged= i;
                            break;
                        }
                    }

                    if (logged >= 0) {
                        page= new Intent(getContext(), MainActivity.class);
                        page.putExtra("users", users);
                        page.putExtra("logged", logged);
                        startActivity(page);
                        Toast.makeText(getContext(), "Login success!", Toast.LENGTH_SHORT).show();
                    } else Toast.makeText(getContext(), "Username/PIN wrong!", Toast.LENGTH_SHORT).show();
                } else Toast.makeText(getContext(), "Field must not empty!", Toast.LENGTH_SHORT).show();
            }
        });

        Toast.makeText(view.getContext(), users.toString(), Toast.LENGTH_SHORT).show();
    }
}
