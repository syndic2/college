package com.example.mdpm6_6615;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class HistoryFragment extends Fragment {
    RadioButton rbIn, rbOut, rbAll;
    EditText edtUsername;
    Button btnShow;
    RecyclerView rvHistories;
    ArrayList<Transaction> displayHistory;
    ArrayList<User> users;
    int logged;
    HistoryAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rbIn= view.findViewById(R.id.rbIn);
        rbOut= view.findViewById(R.id.rbOut);
        rbAll= view.findViewById(R.id.rbAll);
        edtUsername= view.findViewById(R.id.edtUsername);
        btnShow= view.findViewById(R.id.btnShow);
        rvHistories= view.findViewById(R.id.rvHistories);
        displayHistory= new ArrayList<>();
        users= (ArrayList<User>) getArguments().getSerializable("users");
        logged= getArguments().getInt("logged", -1);

        displayHistory.addAll(users.get(logged).getHistories());

        adapter= new HistoryAdapter(displayHistory);

        rvHistories.setHasFixedSize(true);
        rvHistories.setLayoutManager(new LinearLayoutManager(getContext()));
        rvHistories.setAdapter(adapter);

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username= edtUsername.getText().toString();

                if (rbIn.isChecked()) {
                    displayHistory.clear();

                    if (!username.isEmpty()) {
                        for (Transaction transaction : users.get(logged).getHistories()) {
                            if (transaction.getDestination().getUsername().equals(username) && transaction.getType().equals("request")) {
                                displayHistory.add(transaction);
                            }
                        }
                    } else {
                        for (Transaction transaction : users.get(logged).getHistories()) {
                            if (transaction.getType().equals("request")) {
                                displayHistory.add(transaction);
                            }
                        }
                    }

                    if (displayHistory.isEmpty()) Toast.makeText(getContext(), "Transaction not found!", Toast.LENGTH_SHORT).show();
                } else if (rbOut.isChecked()) {
                    displayHistory.clear();

                    if (!username.isEmpty()) {
                        for (Transaction transaction : users.get(logged).getHistories()) {
                            if (transaction.getDestination().getUsername().equals(username) && transaction.getType().equals("send")) {
                                displayHistory.add(transaction);
                            }
                        }
                    } else {
                        for (Transaction transaction : users.get(logged).getHistories()) {
                            if (transaction.getType().equals("send")) {
                                displayHistory.add(transaction);
                            }
                        }
                    }

                    if (displayHistory.isEmpty()) Toast.makeText(getContext(), "Transaction not found!", Toast.LENGTH_SHORT).show();
                } else if (rbAll.isChecked()) {
                    displayHistory.clear();

                    if (!username.isEmpty()) {
                        for (Transaction transaction : users.get(logged).getHistories()) {
                            if (transaction.getDestination().getUsername().equals(username)) {
                                displayHistory.add(transaction);
                            }
                        }
                    } else {
                        displayHistory.addAll(users.get(logged).getHistories());
                    }

                    if (displayHistory.isEmpty()) Toast.makeText(getContext(), "Transaction not found!", Toast.LENGTH_SHORT).show();
                }

                adapter.notifyDataSetChanged();
            }
        });
    }
}
