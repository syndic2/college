#include <iostream>

using namespace std;

int main ()
{

int sisi,l,k,v;
    cin>> sisi;

    l= sisi*sisi;
    cout<< "Luas : " <<l<<" "<<"m^2";

    k= 2*(sisi+sisi);
    cout<< "\nKeliling : " << k;

    v= sisi*sisi*sisi;
    cout<< "\nVolume : " <<v<<" "<<"m^3";

return 0;
}
